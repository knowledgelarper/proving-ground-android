import type { Ammo, AmmoType, Confidence, Core, Era } from "./types";

type Extra = Partial<
  Pick<
    Ammo,
    | "tau"
    | "quality"
    | "penD"
    | "flightMassKg"
    | "rodLengthMm"
    | "rodDiameterMm"
    | "core"
    | "anchorPenMm"
    | "anchorVelocityMs"
    | "table"
    | "heatPenMm"
    | "standoffCd"
    | "tandem"
    | "note"
    | "confidence"
  >
>;

function R(
  id: string,
  name: string,
  nation: string,
  year: number,
  era: Era,
  gun: string,
  type: AmmoType,
  d: number,
  m: number,
  v: number,
  extra: Extra = {},
): Ammo {
  return {
    id,
    name,
    nation,
    year,
    era,
    gun,
    type,
    caliberMm: d,
    massKg: m,
    velocityMs: v,
    confidence: extra.confidence ?? (extra.table ? "published" : extra.anchorPenMm || extra.heatPenMm ? "representative" : "calculated"),
    ...extra,
  };
}

const pub = (note: string): Extra => ({ confidence: "published", note });
const rep = (pen: number, note?: string): Extra => ({
  anchorPenMm: pen,
  confidence: "representative",
  note,
});
const est = (pen: number, note?: string): Extra => ({
  anchorPenMm: pen,
  confidence: "estimate",
  note,
});

export const AMMUNITION: Ammo[] = [
  // ——— Pre-modern & black powder ———
  R("bodkin", "Bodkin arrow", "England", 1350, "ancient", "Warbow", "ap", 10, 0.05, 55, {
    quality: 0.08,
    core: "iron",
    confidence: "calculated",
    note: "De Marre is the wrong family for a 100-joule arrow. The number is only a hint against timber and hide.",
  }),
  R("bolt", "Heavy crossbow bolt", "Europe", 1400, "ancient", "Windlass crossbow", "ap", 14, 0.09, 60, {
    quality: 0.1,
    core: "iron",
    confidence: "calculated",
    note: "Same caveat as the arrow. Useful against the wagon and the chariot, not against iron plate.",
  }),
  R("12pdr", "12-pounder round shot", "Britain", 1812, "blackpowder", "12-pdr smoothbore", "shot", 117, 5.44, 460, {
    quality: 0.55,
    tau: 2200,
    core: "iron",
    confidence: "calculated",
    note: "Cast-iron sphere. Quality is cut because De Marre assumes a pointed steel shot.",
  }),
  R("24pdr", "24-pounder round shot", "Britain", 1812, "blackpowder", "24-pdr smoothbore", "shot", 147, 10.9, 450, {
    quality: 0.55,
    tau: 2400,
    core: "iron",
  }),
  R("32pdr", "32-pounder round shot", "Britain", 1850, "blackpowder", "32-pdr", "shot", 162, 14.5, 480, {
    quality: 0.55,
    tau: 2600,
    core: "iron",
  }),
  R("68pdr", "68-pounder shot", "Britain", 1860, "ironclad", "68-pdr 95 cwt", "shot", 203, 30.8, 480, {
    quality: 0.52,
    tau: 2800,
    core: "iron",
    confidence: "representative",
    note: "The gun HMS Warrior was built to keep out.",
  }),
  R("dahlgren", "XI-inch Dahlgren shot", "USA", 1862, "ironclad", "Dahlgren XI-inch", "shot", 279, 75, 340, {
    quality: 0.5,
    tau: 2600,
    core: "iron",
    confidence: "representative",
    note: "Low-velocity smoothbore shell-gun. Monitor's own weapon, and the sort of thing her turret was built to stand.",
  }),
  R("palliser", "Palliser chilled shot", "Britain", 1870, "ironclad", "7-inch RML", "ap", 178, 52, 430, {
    quality: 0.85,
    tau: 4000,
    core: "iron",
    confidence: "representative",
    note: "Pointed chilled-iron armor-piercing shot, the step between round shot and steel AP.",
  }),
  R("12in-ap", "12-inch AP Mark 7", "USA", 1918, "ww1", "12\"/50", "apcbc", 305, 395, 850, {
    ...est(520, "Naval Class-A performance transposed onto RHA. Not a tank-plate trial."),
    tau: 18000,
    core: "steel",
  }),

  // ——— Small arms & autocannon ———
  R("m193", "5.56 mm M193", "USA", 1963, "coldwar", "M16", "ap", 5.56, 0.0036, 990, {
    ...rep(3, "Ball, not armor piercing. A few millimetres of RHA at the muzzle is the right order."),
    tau: 700,
  }),
  R("m855", "5.56 mm M855", "USA", 1980, "coldwar", "M16A2", "ap", 5.56, 0.004, 948, {
    ...rep(4, "Steel tip, still a rifle ball. Mild steel and thin aluminum, not RHA plate."),
    tau: 750,
  }),
  R("m855a1", "5.56 mm M855A1", "USA", 2010, "modern", "M4", "ap", 5.56, 0.004, 960, {
    ...est(8, "EPR. Open claims versus mild steel are higher than versus RHA; anchor is RHA-ish."),
    tau: 780,
    core: "steel",
  }),
  R("m80", "7.62 mm M80", "USA", 1950, "coldwar", "M14 / GPMG", "ap", 7.62, 0.0095, 840, {
    ...rep(4, "Ball."),
    tau: 900,
  }),
  R("m61-762", "7.62 mm M61 AP", "NATO", 1950, "coldwar", "7.62 NATO", "ap", 7.62, 0.0097, 850, {
    ...rep(8, "NATO AP. Around 7–8 mm RHA at the muzzle in open tables."),
    tau: 950,
    core: "steel",
  }),
  R("30-06-ap", ".30-06 M2 AP", "USA", 1926, "interwar", "M1 Garand / M1919", "ap", 7.62, 0.0109, 855, {
    ...rep(12, "Classic rifle AP, about 10–12 mm of armor at short range."),
    tau: 1000,
    core: "steel",
  }),
  R("762r-b32", "7.62×54R B-32", "USSR", 1930, "ww2", "Mosin / PK", "ap", 7.62, 0.0104, 860, {
    ...rep(11, "API. Hardened core plus incendiary."),
    tau: 950,
    core: "steel",
  }),
  R("303", ".303 Mk VII", "Britain", 1910, "ww1", "Lee-Enfield", "ap", 7.7, 0.0113, 744, {
    ...rep(3, "Ball. Cordite Mark VII."),
    tau: 800,
  }),
  R("k98-smk", "7.92 mm SmK", "Germany", 1939, "ww2", "Kar98k / MG42", "ap", 7.92, 0.0115, 800, {
    ...rep(11, "Spitzgeschoss mit Kern. The German rifle AP of 1940."),
    tau: 950,
    core: "steel",
  }),
  R("338", ".338 Lapua AP", "Finland", 1989, "modern", ".338 LM", "ap", 8.6, 0.0162, 900, {
    ...est(14, "AP load, open estimate versus RHA."),
    tau: 1400,
    core: "wc",
    penD: 7,
  }),
  R("50-m2", ".50 BMG M2 AP", "USA", 1920, "interwar", "M2 Browning", "ap", 12.7, 0.046, 887, {
    ...rep(22, "About 22 mm RHA at the muzzle. The round the M113's front was not quite sure of."),
    tau: 1400,
    core: "steel",
  }),
  R("50-m8", ".50 BMG M8 API", "USA", 1943, "ww2", "M2 Browning", "ap", 12.7, 0.042, 887, {
    ...rep(20, "API, a little less steel than M2 AP."),
    tau: 1300,
    core: "steel",
  }),
  R("50-slap", ".50 SLAP", "USA", 1980, "coldwar", "M2 / Barrett", "apds", 12.7, 0.023, 1219, {
    penD: 7.7,
    ...est(34, "Saboted light armor penetrator. Tungsten slug, open estimate."),
    tau: 1800,
    core: "tungsten",
  }),
  R("145-b32", "14.5 mm B-32", "USSR", 1941, "ww2", "PTRD / KPV", "ap", 14.5, 0.064, 1000, {
    ...rep(38, "About 40 mm RHA at short range is the usual claim; 38 mm is the anchor."),
    tau: 1600,
    core: "steel",
  }),
  R("145-bs41", "14.5 mm BS-41", "USSR", 1941, "ww2", "PTRS", "ap", 14.5, 0.065, 1000, {
    penD: 12,
    ...rep(45, "Tungsten-carbide core. The anti-tank rifle round that could threaten a Panzer III side."),
    tau: 1500,
    core: "wc",
  }),
  R("20-hisp", "20×110 Hispano AP", "Britain", 1941, "ww2", "Hispano Mk II", "ap", 20, 0.13, 850, {
    ...rep(25, "Aircraft cannon AP."),
    tau: 1800,
  }),
  R("20-mg151", "20 mm MG 151 AP", "Germany", 1940, "ww2", "MG 151/20", "ap", 20, 0.117, 720, {
    ...rep(22),
    tau: 1600,
  }),
  R("20-dm43", "20×139 DM43 APDS", "Germany", 1970, "coldwar", "Rh 202", "apds", 20, 0.072, 1150, {
    penD: 12,
    ...est(50, "Autocannon APDS, open estimate."),
    tau: 2200,
    core: "tungsten",
  }),
  R("25-m791", "25 mm M791 APDS", "USA", 1980, "coldwar", "M242 Bushmaster", "apds", 25, 0.102, 1345, {
    penD: 14,
    ...est(55, "Bradley gun. Open estimate versus RHA."),
    tau: 2400,
    core: "tungsten",
  }),
  R("30-gau", "30 mm PGU-14 API", "USA", 1977, "coldwar", "GAU-8 Avenger", "ap", 30, 0.43, 988, {
    penD: 16,
    core: "du",
    ...est(70, "Depleted-uranium core in an aluminum jacket. Often quoted near 70 mm RHA at muzzle. Estimate."),
    tau: 2000,
  }),
  R("30-2a42", "30 mm 3UBR8 APDS", "USSR", 1980, "coldwar", "2A42", "apds", 30, 0.3, 1120, {
    penD: 16,
    ...est(50),
    tau: 2200,
    core: "tungsten",
  }),

  // ——— WWI & interwar guns ———
  R("37-puteaux", "37 mm Puteaux AP", "France", 1916, "ww1", "SA 18", "ap", 37, 0.5, 600, {
    ...rep(18, "Renault FT gun. Trenches, not tanks that mattered later."),
    tau: 2500,
  }),
  R("37-kwk36", "3.7 cm PzGr", "Germany", 1936, "interwar", "3.7 cm KwK 36", "ap", 37, 0.68, 745, {
    table: [
      [100, 35],
      [500, 29],
      [1000, 22],
    ],
    confidence: "published",
    note: "Early Panzer III gun. Vertical figures in the usual 0° compilation.",
  }),
  R("37-m5", "37 mm M74 AP", "USA", 1940, "ww2", "37 mm M5/M6", "ap", 37, 0.87, 884, {
    ...rep(60, "US light-tank gun. About 60 mm vertical at the muzzle is the common table."),
    tau: 3500,
  }),
  R("40-2pdr", "2-pounder AP", "Britain", 1937, "ww2", "2-pdr", "ap", 40, 1.08, 792, {
    ...rep(64, "Little explosive, flat nose later. About 60 mm class vertical."),
  }),
  R("47-sa35", "47 mm SA 35", "France", 1935, "interwar", "SA 35", "ap", 47, 1.6, 660, {
    ...rep(40),
  }),
  R("47-jap", "47 mm Type 1 AP", "Japan", 1941, "ww2", "Type 1", "ap", 47, 1.4, 810, {
    ...rep(65, "Best Japanese tank gun of the war. Still short of a Sherman glacis."),
  }),
  R("45-br240", "45 mm BR-240", "USSR", 1937, "ww2", "20-K / 45 mm", "apbc", 45, 1.43, 760, {
    ...rep(43, "T-26 / BT gun. Representative 0° figure near the muzzle."),
  }),

  // ——— German WWII ———
  R("50-l42", "5 cm PzGr.39", "Germany", 1940, "ww2", "5 cm KwK 38 L/42", "apcbc", 50, 2.06, 685, {
    ...rep(70, "Short 50. Representative vertical figure."),
  }),
  R("50-l60", "5 cm PzGr.39", "Germany", 1941, "ww2", "5 cm KwK 39 L/60", "apcbc", 50, 2.06, 835, {
    ...rep(95, "Long 50. The gun that made the Panzer III a real anti-tank tank, briefly."),
  }),
  R("50-pzgr40", "5 cm PzGr.40", "Germany", 1941, "ww2", "5 cm KwK 39 L/60", "apcr", 50, 0.9, 1180, {
    penD: 28,
    core: "wc",
    ...rep(140, "Tungsten core. Fast, light, bad on slope, and scarce."),
    tau: 3800,
  }),
  R("75-l24", "7.5 cm K.Gr.rot Pz.", "Germany", 1939, "ww2", "7.5 cm KwK 37 L/24", "apcbc", 75, 6.8, 385, {
    ...rep(45, "Short 75. Howitzer ballistics. HEAT was the later answer."),
    tau: 4000,
  }),
  R("75-hl", "7.5 cm Gr.38 HL/C", "Germany", 1942, "ww2", "7.5 cm KwK 40 / L/24", "heat", 75, 4.6, 450, {
    heatPenMm: 115,
    confidence: "published",
    note: "Hollow charge. Penetration stays flat with range. About 100–115 mm is the usual HL/C figure.",
  }),
  R("75-l48", "7.5 cm PzGr.39", "Germany", 1942, "ww2", "7.5 cm KwK 40 L/48", "apcbc", 75, 6.8, 750, {
    table: [
      [100, 138],
      [500, 124],
      [1000, 113],
      [1500, 102],
      [2000, 91],
      [2500, 82],
    ],
    confidence: "published",
    note: "Vertical RHA, Aberdeen / Ordnance Board style compilation, ~BHN 270. Other tables sit a few millimetres either side.",
  }),
  R("75-pzgr40", "7.5 cm PzGr.40", "Germany", 1942, "ww2", "7.5 cm KwK 40 L/48", "apcr", 75, 4.1, 990, {
    penD: 40,
    core: "wc",
    table: [
      [100, 154],
      [500, 130],
      [1000, 100],
    ],
    tau: 4000,
    confidence: "published",
    note: "APCR. The table falls off a cliff because the light core sheds speed.",
  }),
  R("75-l70", "7.5 cm PzGr.39/42", "Germany", 1943, "ww2", "7.5 cm KwK 42 L/70", "apcbc", 75, 6.8, 925, {
    table: [
      [100, 173],
      [500, 164],
      [1000, 156],
      [1500, 137],
      [2000, 121],
      [2500, 108],
    ],
    confidence: "published",
    note: "Panther gun. Some German tables quote higher; this is the conservative 0° series.",
  }),
  R("75-l70-40", "7.5 cm PzGr.40/42", "Germany", 1943, "ww2", "7.5 cm KwK 42 L/70", "apcr", 75, 4.75, 1120, {
    penD: 40,
    core: "wc",
    ...rep(210, "Panther APCR. Representative close-range vertical figure."),
    tau: 4200,
  }),
  R("88-l56", "8.8 cm PzGr.39", "Germany", 1941, "ww2", "8.8 cm KwK 36 L/56", "apcbc", 88, 10.2, 780, {
    table: [
      [100, 155],
      [500, 143],
      [1000, 133],
      [1500, 122],
      [2000, 110],
      [2500, 101],
    ],
    confidence: "published",
    tau: 9500,
    note: "Tiger I gun. Vertical series around BHN 270. German 30° tables are a different column and are not mixed in here.",
  }),
  R("88-l56-40", "8.8 cm PzGr.40", "Germany", 1942, "ww2", "8.8 cm KwK 36 L/56", "apcr", 88, 7.3, 930, {
    penD: 50,
    core: "wc",
    ...rep(200, "Rare tungsten 88. Representative."),
    tau: 5000,
  }),
  R("88-l71", "8.8 cm PzGr.39/43", "Germany", 1943, "ww2", "8.8 cm KwK 43 L/71", "apcbc", 88, 10.4, 1000, {
    table: [
      [100, 222],
      [500, 206],
      [1000, 185],
      [1500, 167],
      [2000, 150],
      [2500, 132],
    ],
    tau: 11000,
    confidence: "published",
    note: "King Tiger / Jagdpanther / Nashorn gun.",
  }),
  R("88-l71-40", "8.8 cm PzGr.40/43", "Germany", 1944, "ww2", "8.8 cm KwK 43 L/71", "apcr", 88, 7.3, 1130, {
    penD: 50,
    core: "wc",
    ...rep(260),
    tau: 5200,
  }),
  R("128-pzgr", "12.8 cm PzGr.43", "Germany", 1944, "ww2", "12.8 cm PaK 44", "apcbc", 128, 28.3, 920, {
    ...rep(250, "Jagdtiger gun. Representative vertical figure near the muzzle; sources spread from ~200 to ~270."),
    tau: 12000,
  }),

  // ——— Soviet WWII ———
  R("76-br350b", "76 mm BR-350B", "USSR", 1941, "ww2", "F-34", "apbc", 76, 6.3, 655, {
    ...rep(86, "T-34-76 gun. Representative 0° figure near 100 m."),
  }),
  R("76-br350p", "76 mm BR-350P", "USSR", 1943, "ww2", "F-34", "apcr", 76, 3.05, 950, {
    penD: 40,
    core: "wc",
    ...rep(110),
    tau: 4000,
  }),
  R("57-zis", "57 mm BR-271", "USSR", 1941, "ww2", "ZiS-2", "ap", 57, 3.14, 990, {
    ...rep(145, "The high-velocity 57. Representative."),
  }),
  R("85-br365", "85 mm BR-365", "USSR", 1944, "ww2", "D-5T / ZiS-S-53", "apbc", 85, 9.2, 792, {
    ...rep(125, "T-34-85 APC. Representative vertical series near the muzzle."),
    tau: 8000,
  }),
  R("85-br365p", "85 mm BR-365P", "USSR", 1944, "ww2", "ZiS-S-53", "apcr", 85, 4.9, 1050, {
    penD: 45,
    core: "wc",
    ...rep(160),
    tau: 4500,
  }),
  R("100-br412d", "100 mm BR-412D", "USSR", 1944, "ww2", "D-10 / BS-3", "apcbc", 100, 15.9, 887, {
    ...rep(200, "SU-100 / T-54 gun, wartime APCBC. Representative."),
    tau: 10000,
  }),
  R("122-br471", "122 mm BR-471", "USSR", 1944, "ww2", "D-25T", "ap", 122, 25, 780, {
    ...rep(155, "IS-2 sharp-nosed AP. Blunt BR-471B is the slope round; this is the early AP."),
    tau: 11000,
  }),
  R("122-br471b", "122 mm BR-471B", "USSR", 1944, "ww2", "D-25T", "apbc", 122, 25, 780, {
    ...rep(160, "Blunter nose, better on slope, huge overmatch. Representative."),
    tau: 11000,
  }),
  R("152-heat", "152 mm BP-540 HEAT", "USSR", 1944, "ww2", "SU-152 / ISU-152", "heat", 152, 27, 430, {
    heatPenMm: 250,
    confidence: "representative",
    note: "Late hollow charge for the howitzer. The earlier work was plain HE, which is a separate row.",
  }),
  R("152-he", "152 mm OF-540 HE", "USSR", 1943, "ww2", "ML-20S", "he", 152, 43, 600, {
    quality: 0.28,
    confidence: "calculated",
    note: "Shell-body penetration only. The famous effect on a Tiger was blast and plate shock, which this model does not score.",
  }),

  // ——— Allied WWII ———
  R("6pdr", "6-pounder APCBC", "Britain", 1942, "ww2", "6-pdr Mk 5", "apcbc", 57, 3.2, 850, {
    ...rep(110, "Representative vertical figure."),
  }),
  R("6pdr-apds", "6-pounder APDS", "Britain", 1944, "ww2", "6-pdr", "apds", 57, 1.5, 1230, {
    penD: 32,
    core: "wc",
    ...rep(160, "First service APDS. Accurate enough at short range, fussy on slope."),
    tau: 7000,
  }),
  R("75-m61", "75 mm M61 APCBC", "USA", 1941, "ww2", "75 mm M3", "apcbc", 75, 6.8, 619, {
    ...rep(90, "Sherman gun. About 90 mm vertical near the muzzle in US tables."),
    tau: 7000,
  }),
  R("76-m62", "76 mm M62 APCBC", "USA", 1943, "ww2", "76 mm M1", "apcbc", 76, 7, 792, {
    ...rep(125, "Easy Eight / M18 gun, APCBC."),
    tau: 8500,
  }),
  R("76-m93", "76 mm M93 HVAP", "USA", 1944, "ww2", "76 mm M1", "apcr", 76, 4.3, 1036, {
    penD: 42,
    core: "wc",
    ...rep(175, "HVAP. Scarce in 1944."),
    tau: 4500,
  }),
  R("17-apcbc", "17-pounder APCBC", "Britain", 1943, "ww2", "17-pdr", "apcbc", 76.2, 7.7, 884, {
    ...rep(165, "Firefly / Achilles full-caliber shot. Sources range roughly 150–180 mm vertical."),
    tau: 9000,
  }),
  R("17-apds", "17-pounder APDS", "Britain", 1944, "ww2", "17-pdr", "apds", 76.2, 1.7, 1204, {
    penD: 38,
    core: "wc",
    table: [
      [100, 275],
      [500, 256],
      [1000, 233],
      [1500, 213],
      [2000, 194],
    ],
    tau: 9000,
    confidence: "published",
    note: "One Ordnance Board style series versus vertical ~240 BHN plate. Shatter made the field result worse than the table.",
  }),
  R("77-apds", "77 mm APDS", "Britain", 1945, "ww2", "77 mm Comet", "apds", 76.2, 1.7, 1120, {
    penD: 38,
    core: "wc",
    ...rep(220, "Comet's shorter 17-pounder case."),
    tau: 8500,
  }),
  R("90-m82", "90 mm M82 APCBC", "USA", 1944, "ww2", "90 mm M3", "apcbc", 90, 10.9, 813, {
    ...rep(160, "Pershing / M36 gun, full caliber."),
    tau: 9500,
  }),
  R("90-m304", "90 mm M304 HVAP", "USA", 1945, "ww2", "90 mm M3", "apcr", 90, 7.6, 1021, {
    penD: 48,
    core: "wc",
    ...rep(250),
    tau: 5000,
  }),
  R("90-t33", "90 mm T33 APBC", "USA", 1945, "ww2", "90 mm M3", "apbc", 90, 11, 853, {
    ...rep(170, "Reworked HVAP-era solid shot with a better nose for slope."),
  }),

  // ——— Naval WWII, transposed ———
  R("5-38", "5\"/38 Special Common", "USA", 1940, "ww2", "5\"/38", "ap", 127, 25, 792, {
    ...est(130, "Special common, not a tank AP. RHA transposition."),
    tau: 12000,
  }),
  R("8-ap", "8-inch AP Mark 21", "USA", 1942, "ww2", "8\"/55", "apcbc", 203, 118, 760, {
    ...est(280, "Cruiser AP transposed onto RHA."),
    tau: 16000,
  }),
  R("11-scharn", "283 mm Psgr", "Germany", 1939, "ww2", "28 cm SK C/34", "apcbc", 283, 330, 890, {
    ...est(480, "Scharnhorst gun. Class-A naval performance is not RHA; this is a transposition."),
    tau: 20000,
  }),
  R("15-bismarck", "380 mm Psgr L/4,4", "Germany", 1940, "ww2", "38 cm SK C/34", "apcbc", 380, 800, 820, {
    ...est(640, "Bismarck AP, RHA transposition, muzzle region."),
    tau: 22000,
  }),
  R("16-mk8", "16\" Mark 8 AP", "USA", 1943, "ww2", "16\"/50 Mark 7", "apcbc", 406, 1225, 762, {
    ...est(760, "Iowa super-heavy AP. Open muzzle charts versus US Class A, transposed. A 1.2-ton shell is not a long-rod test."),
    tau: 24000,
  }),
  R("yamato", "Type 91 46 cm AP", "Japan", 1941, "ww2", "46 cm/45", "apcbc", 460, 1460, 780, {
    ...est(820, "Yamato AP. Same caveat as the Iowa shell, louder."),
    tau: 25000,
  }),

  // ——— Cold War guns ———
  R("20pdr", "20-pounder APDS", "Britain", 1948, "coldwar", "20-pdr", "apds", 83.4, 3.2, 1430, {
    penD: 42,
    core: "wc",
    ...rep(280, "Centurion Mk 3 gun."),
    tau: 10000,
  }),
  R("90-m431", "90 mm M431 HEAT", "USA", 1960, "coldwar", "90 mm M41", "heat", 90, 5.9, 1200, {
    heatPenMm: 320,
    confidence: "representative",
  }),
  R("100-3bm8", "100 mm 3BM8 APDS", "USSR", 1966, "coldwar", "D-10T", "apds", 100, 4.1, 1415, {
    penD: 45,
    core: "tungsten",
    ...est(280),
    tau: 10000,
  }),
  R("100-3bk5", "100 mm 3BK5 HEAT", "USSR", 1961, "coldwar", "D-10T", "heat", 100, 12, 900, {
    heatPenMm: 380,
    confidence: "representative",
  }),
  R("105-l28", "105 mm L28 APDS", "Britain", 1958, "coldwar", "L7", "apds", 105, 4.2, 1478, {
    penD: 48,
    core: "tungsten",
    ...rep(300, "Early L7 APDS, also M392 in US service. Representative."),
    tau: 11000,
  }),
  R("105-m456", "105 mm M456 HEAT", "USA", 1959, "coldwar", "L7 / M68", "heat", 105, 10.2, 1173, {
    heatPenMm: 400,
    confidence: "representative",
  }),
  R("105-m111", "105 mm M111 Hetz", "Israel", 1978, "coldwar", "L7", "apfsds", 105, 4.2, 1455, {
    penD: 32,
    rodLengthMm: 420,
    rodDiameterMm: 28,
    core: "tungsten",
    flightMassKg: 6.3,
    ...est(400, "The round built to defeat the T-72 glacis. Open estimate near 380–420 mm at combat range; anchor is muzzle-region."),
  }),
  R("105-m735", "105 mm M735", "USA", 1978, "coldwar", "M68", "apfsds", 105, 3.7, 1501, {
    rodLengthMm: 440,
    rodDiameterMm: 26,
    core: "tungsten",
    ...est(340),
  }),
  R("105-m774", "105 mm M774", "USA", 1980, "coldwar", "M68", "apfsds", 105, 3.4, 1508, {
    rodLengthMm: 460,
    rodDiameterMm: 24,
    core: "du",
    ...est(430, "First DU 105. Open estimate."),
  }),
  R("105-m833", "105 mm M833", "USA", 1983, "coldwar", "M68", "apfsds", 105, 3.7, 1494, {
    rodLengthMm: 500,
    rodDiameterMm: 24,
    core: "du",
    ...est(480),
  }),
  R("105-dm33", "105 mm DM33", "Germany", 1984, "coldwar", "L7", "apfsds", 105, 3.8, 1455, {
    rodLengthMm: 480,
    rodDiameterMm: 25,
    core: "tungsten",
    ...est(470),
  }),
  R("105-dm63", "105 mm DM63", "Germany", 1990, "modern", "L7", "apfsds", 105, 4.3, 1450, {
    rodLengthMm: 520,
    rodDiameterMm: 24,
    core: "tungsten",
    ...est(500),
  }),
  R("115-3bm3", "115 mm 3BM3", "USSR", 1961, "coldwar", "2A20", "apfsds", 115, 4, 1615, {
    rodLengthMm: 410,
    rodDiameterMm: 32,
    core: "steel",
    ...est(280, "Early steel dart for the T-62. Short and fat by later standards."),
  }),
  R("115-3bm6", "115 mm 3BM6", "USSR", 1968, "coldwar", "2A20", "apfsds", 115, 3.9, 1680, {
    rodLengthMm: 450,
    rodDiameterMm: 28,
    core: "tungsten",
    ...est(320),
  }),
  R("115-3bk4", "115 mm 3BK4 HEAT", "USSR", 1961, "coldwar", "2A20", "heat", 115, 12, 950, {
    heatPenMm: 440,
    confidence: "representative",
  }),
  R("120-l15", "120 mm L15 APDS", "Britain", 1968, "coldwar", "L11", "apds", 120, 7.5, 1370, {
    penD: 55,
    core: "tungsten",
    ...rep(320, "Chieftain APDS, before CHARM."),
    tau: 11000,
  }),
  R("120-hesh", "120 mm L31 HESH", "Britain", 1965, "coldwar", "L11", "hesh", 120, 17.1, 670, {
    confidence: "representative",
    note: "Squash head. Defeats by scab, not by a hole. Fails on composite and spaced armor.",
  }),
  R("165-hesh", "165 mm HESH", "Britain", 1960, "coldwar", "L9 AVRE", "hesh", 165, 29, 260, {
    confidence: "representative",
    note: "Demolition HESH. Enormous pat, miserable velocity.",
  }),
  R("125-3bm9", "125 mm 3BM9", "USSR", 1968, "coldwar", "2A46", "apfsds", 125, 3.6, 1800, {
    rodLengthMm: 410,
    rodDiameterMm: 36,
    core: "steel",
    ...est(320, "First T-64/T-72 dart. Steel, high speed, modest penetration."),
  }),
  R("125-3bm15", "125 mm 3BM15", "USSR", 1972, "coldwar", "2A46", "apfsds", 125, 3.9, 1780, {
    rodLengthMm: 480,
    rodDiameterMm: 32,
    core: "tungsten",
    ...est(380),
  }),
  R("125-3bm22", "125 mm 3BM22", "USSR", 1976, "coldwar", "2A46", "apfsds", 125, 4.5, 1760, {
    rodLengthMm: 520,
    rodDiameterMm: 30,
    core: "tungsten",
    ...est(430),
  }),
  R("125-3bm26", "125 mm 3BM26", "USSR", 1983, "coldwar", "2A46", "apfsds", 125, 4.8, 1720, {
    rodLengthMm: 540,
    rodDiameterMm: 28,
    core: "tungsten",
    ...est(460),
  }),
  R("125-3bm32", "125 mm 3BM32 Vant", "USSR", 1985, "coldwar", "2A46", "apfsds", 125, 4.85, 1700, {
    rodLengthMm: 480,
    rodDiameterMm: 26,
    core: "du",
    ...est(520, "DU monobloc. Open estimate."),
  }),
  R("125-3bm42", "125 mm 3BM42 Mango", "USSR", 1986, "coldwar", "2A46", "apfsds", 125, 4.85, 1700, {
    rodLengthMm: 560,
    rodDiameterMm: 26,
    core: "tungsten",
    ...est(520, "The export workhorse. Open estimates cluster near 450 mm at 2 km and a bit over 500 at the muzzle."),
  }),
  R("125-3bm42m", "125 mm 3BM42M Lekalo", "Russia", 1994, "modern", "2A46", "apfsds", 125, 4.6, 1750, {
    rodLengthMm: 640,
    rodDiameterMm: 22,
    core: "tungsten",
    ...est(600),
  }),
  R("125-3bm46", "125 mm 3BM46 Svinets", "Russia", 1991, "modern", "2A46M", "apfsds", 125, 4.5, 1660, {
    rodLengthMm: 640,
    rodDiameterMm: 24,
    core: "du",
    ...est(610),
  }),
  R("125-3bm59", "125 mm 3BM59 Svinets-1", "Russia", 2002, "modern", "2A46M-5", "apfsds", 125, 6.8, 1650, {
    rodLengthMm: 730,
    rodDiameterMm: 22,
    core: "du",
    ...est(680, "Long DU rod. Dimensions and penetration are open estimates."),
  }),
  R("125-3bm60", "125 mm 3BM60 Svinets-2", "Russia", 2002, "modern", "2A46M-5", "apfsds", 125, 7.0, 1650, {
    rodLengthMm: 740,
    rodDiameterMm: 22,
    core: "tungsten",
    ...est(670),
  }),
  R("125-3bk18", "125 mm 3BK18M HEAT", "USSR", 1970, "coldwar", "2A46", "heat", 125, 19, 905, {
    heatPenMm: 550,
    confidence: "representative",
  }),
  R("125-3bk29", "125 mm 3BK29 HEAT", "Russia", 1988, "coldwar", "2A46", "heat", 125, 18.4, 915, {
    heatPenMm: 800,
    tandem: true,
    confidence: "estimate",
    note: "Tandem. The precursor is assumed to spend one ERA cassette.",
  }),
  R("120-dm13", "120 mm DM13", "West Germany", 1979, "coldwar", "Rh 120 L/44", "apfsds", 120, 4.6, 1650, {
    rodLengthMm: 450,
    rodDiameterMm: 32,
    core: "tungsten",
    ...est(440, "First Leopard 2 service dart."),
  }),
  R("120-dm23", "120 mm DM23", "West Germany", 1983, "coldwar", "Rh 120 L/44", "apfsds", 120, 4.3, 1650, {
    rodLengthMm: 480,
    rodDiameterMm: 30,
    core: "tungsten",
    ...est(480),
  }),
  R("120-dm33", "120 mm DM33", "West Germany", 1987, "coldwar", "Rh 120 L/44", "apfsds", 120, 4.6, 1650, {
    rodLengthMm: 540,
    rodDiameterMm: 26,
    core: "tungsten",
    ...est(560),
  }),
  R("120-dm43", "120 mm DM43", "Germany", 1993, "modern", "Rh 120 L/44", "apfsds", 120, 4.3, 1740, {
    rodLengthMm: 600,
    rodDiameterMm: 24,
    core: "tungsten",
    ...est(640),
  }),
  R("120-dm53", "120 mm DM53", "Germany", 1999, "modern", "Rh 120 L/44", "apfsds", 120, 5, 1670, {
    rodLengthMm: 680,
    rodDiameterMm: 22,
    core: "tungsten",
    ...est(730, "L/44 muzzle. The L/55 sibling is the next row. Open estimate, often quoted 700–760 mm at 100 m."),
  }),
  R("120-dm53-l55", "120 mm DM53 L/55", "Germany", 2001, "modern", "Rh 120 L/55", "apfsds", 120, 5, 1750, {
    rodLengthMm: 680,
    rodDiameterMm: 22,
    core: "tungsten",
    ...est(770, "Same dart, more gun. Open estimate."),
  }),
  R("120-dm63", "120 mm DM63", "Germany", 2005, "modern", "Rh 120 L/55", "apfsds", 120, 5, 1720, {
    rodLengthMm: 680,
    rodDiameterMm: 22,
    core: "tungsten",
    ...est(760, "Temperature-stable DM53 successor. Penetration treated as the same class."),
  }),
  R("120-dm73", "120 mm DM73", "Germany", 2023, "modern", "Rh 120 L/55", "apfsds", 120, 5.2, 1780, {
    rodLengthMm: 720,
    rodDiameterMm: 22,
    core: "tungsten",
    ...est(800, "Public successor round. Penetration is an estimate, not a released proof."),
  }),
  R("120-m829", "120 mm M829", "USA", 1985, "coldwar", "M256", "apfsds", 120, 4.3, 1670, {
    rodLengthMm: 540,
    rodDiameterMm: 27,
    core: "du",
    ...est(570),
  }),
  R("120-m829a1", "120 mm M829A1", "USA", 1988, "coldwar", "M256", "apfsds", 120, 4.6, 1675, {
    rodLengthMm: 680,
    rodDiameterMm: 22,
    core: "du",
    ...est(690, "Silver bullet. Open estimates near 650–700 mm at combat range."),
  }),
  R("120-m829a2", "120 mm M829A2", "USA", 1994, "modern", "M256", "apfsds", 120, 4.7, 1680, {
    rodLengthMm: 700,
    rodDiameterMm: 22,
    core: "du",
    ...est(740),
  }),
  R("120-m829a3", "120 mm M829A3", "USA", 2003, "modern", "M256", "apfsds", 120, 6.2, 1555, {
    rodLengthMm: 780,
    rodDiameterMm: 22,
    core: "du",
    ...est(820, "Longer, slower, anti-ERA features in the nose that this model only partly captures via length."),
  }),
  R("120-m829a4", "120 mm M829A4", "USA", 2016, "modern", "M256", "apfsds", 120, 6.5, 1650, {
    rodLengthMm: 800,
    rodDiameterMm: 22,
    core: "du",
    ...est(880, "Classified. The anchor is a public guess, flagged as an estimate on every result."),
  }),
  R("120-l27", "120 mm L27A1 CHARM 3", "Britain", 1999, "modern", "L30", "apfsds", 120, 4.6, 1650, {
    rodLengthMm: 650,
    rodDiameterMm: 24,
    core: "du",
    ...est(670, "Challenger 2 service DU rod. Open estimate."),
  }),
  R("120-ofl-f1", "120 mm OFL F1", "France", 1990, "modern", "CN120-26", "apfsds", 120, 4, 1790, {
    rodLengthMm: 560,
    rodDiameterMm: 26,
    core: "tungsten",
    ...est(600),
  }),
  R("120-ofl-f2", "120 mm OFL F2", "France", 2000, "modern", "CN120-26", "apfsds", 120, 4.5, 1740, {
    rodLengthMm: 640,
    rodDiameterMm: 24,
    core: "du",
    ...est(680),
  }),
  R("120-type10", "Type 10 APFSDS", "Japan", 2012, "modern", "10C", "apfsds", 120, 4.2, 1780, {
    rodLengthMm: 620,
    rodDiameterMm: 22,
    core: "tungsten",
    ...est(720, "Open estimate. The gun is a short high-pressure 120."),
  }),
  R("120-dm12", "120 mm DM12 HEAT", "West Germany", 1979, "coldwar", "Rh 120", "heat", 120, 13.5, 1140, {
    heatPenMm: 600,
    confidence: "representative",
  }),
  R("125-2a83", "152 mm 3BM? APFSDS", "Russia", 2015, "modern", "2A83 (T-14 claim)", "apfsds", 152, 8, 1980, {
    rodLengthMm: 900,
    rodDiameterMm: 28,
    core: "du",
    ...est(1000, "Manufacturer-land claim for a gun most T-14s do not carry. Treated as a claim, not a measurement. Caliber stored as 152."),
  }),

  // ——— Infantry anti-tank ———
  R("piat", "PIAT bomb", "Britain", 1942, "ww2", "PIAT", "heat", 83, 1.1, 137, {
    heatPenMm: 100,
    confidence: "published",
    note: "Spigot mortar. Slow. About 100 mm.",
  }),
  R("bazooka", "M6A3 rocket", "USA", 1943, "ww2", "M1A1 Bazooka", "heat", 60, 1.6, 80, {
    heatPenMm: 100,
    confidence: "published",
    note: "2.36 inch. Early heads were closer to 75–100 mm.",
  }),
  R("superbaz", "M28A2 rocket", "USA", 1945, "ww2", "M20 Super Bazooka", "heat", 89, 4, 100, {
    heatPenMm: 280,
    confidence: "representative",
  }),
  R("panzerschreck", "RPzB.Gr. 4322", "Germany", 1943, "ww2", "Panzerschreck", "heat", 88, 3.3, 110, {
    heatPenMm: 160,
    confidence: "published",
  }),
  R("faust100", "Panzerfaust 100", "Germany", 1944, "ww2", "Panzerfaust", "heat", 149, 3.6, 60, {
    heatPenMm: 200,
    confidence: "published",
    note: "Large head, very short range. Penetration quoted near 200 mm.",
  }),
  R("rpg2", "PG-2", "USSR", 1949, "coldwar", "RPG-2", "heat", 80, 1.8, 84, {
    heatPenMm: 180,
    confidence: "representative",
  }),
  R("pg7v", "PG-7V", "USSR", 1961, "coldwar", "RPG-7", "heat", 85, 2.2, 120, {
    heatPenMm: 260,
    confidence: "published",
  }),
  R("pg7vl", "PG-7VL", "USSR", 1977, "coldwar", "RPG-7", "heat", 93, 2.6, 115, {
    heatPenMm: 500,
    confidence: "representative",
  }),
  R("pg7vr", "PG-7VR", "USSR", 1988, "coldwar", "RPG-7", "heat", 105, 4.5, 120, {
    heatPenMm: 600,
    tandem: true,
    confidence: "estimate",
    note: "Tandem. Precursor then a ~600 mm class main charge behind ERA.",
  }),
  R("carl", "FFV 551 HEAT", "Sweden", 1976, "coldwar", "Carl Gustaf", "heat", 84, 2.2, 240, {
    heatPenMm: 400,
    confidence: "representative",
  }),
  R("at4", "AT4", "Sweden", 1985, "coldwar", "AT4", "heat", 84, 1.8, 290, {
    heatPenMm: 420,
    confidence: "representative",
  }),
  R("panzerfaust3", "Panzerfaust 3", "Germany", 1987, "coldwar", "PzF 3", "heat", 110, 3.8, 240, {
    heatPenMm: 700,
    confidence: "estimate",
    note: "Manufacturer figure is higher; 700 mm is a sober open estimate for the basic head.",
  }),
  R("pz3-it", "Panzerfaust 3-IT", "Germany", 1998, "modern", "PzF 3-IT", "heat", 110, 4, 240, {
    heatPenMm: 900,
    tandem: true,
    confidence: "estimate",
  }),
  R("rpg29", "PG-29V", "USSR", 1989, "modern", "RPG-29", "heat", 105, 6.7, 280, {
    heatPenMm: 750,
    tandem: true,
    confidence: "estimate",
  }),
  R("nlaw", "NLAW", "Britain / Sweden", 2009, "modern", "NLAW", "heat", 150, 6, 200, {
    heatPenMm: 500,
    confidence: "estimate",
    note: "Overfly top-attack is the real mode. This row is direct-attack HEAT only, and top armor is a roof plate you should build.",
  }),

  // ——— ATGMs ———
  R("ss11", "SS.11", "France", 1956, "coldwar", "SS.11", "heat", 164, 28, 190, {
    heatPenMm: 600,
    confidence: "representative",
  }),
  R("malyutka", "9M14 Malyutka", "USSR", 1963, "coldwar", "AT-3 Sagger", "heat", 125, 10.9, 120, {
    heatPenMm: 400,
    confidence: "representative",
  }),
  R("milan", "MILAN", "France / Germany", 1972, "coldwar", "MILAN", "heat", 115, 6.6, 200, {
    heatPenMm: 350,
    confidence: "representative",
  }),
  R("milan2", "MILAN 2", "France / Germany", 1984, "coldwar", "MILAN", "heat", 115, 6.7, 200, {
    heatPenMm: 530,
    confidence: "representative",
  }),
  R("milan3", "MILAN 3", "France", 1996, "modern", "MILAN", "heat", 115, 7, 200, {
    heatPenMm: 900,
    tandem: true,
    confidence: "estimate",
  }),
  R("tow", "BGM-71A TOW", "USA", 1970, "coldwar", "TOW", "heat", 152, 18, 280, {
    heatPenMm: 430,
    confidence: "published",
  }),
  R("tow2", "BGM-71D TOW-2", "USA", 1983, "coldwar", "TOW", "heat", 152, 21, 280, {
    heatPenMm: 900,
    confidence: "estimate",
  }),
  R("tow2a", "BGM-71E TOW-2A", "USA", 1987, "coldwar", "TOW", "heat", 152, 22, 280, {
    heatPenMm: 900,
    tandem: true,
    confidence: "estimate",
    note: "Tandem tip. Open estimates sit around 900 mm behind ERA.",
  }),
  R("tow2b", "BGM-71F TOW-2B", "USA", 1992, "modern", "TOW", "heat", 149, 22, 280, {
    heatPenMm: 300,
    tandem: true,
    confidence: "estimate",
    note: "Flyover EFP, not a nose jet. 300 mm is a stand-in if you aim it at a roof plate. Do not read it as turret-front performance.",
  }),
  R("hellfire", "AGM-114K Hellfire", "USA", 1990, "modern", "Hellfire II", "heat", 178, 9, 450, {
    heatPenMm: 1200,
    tandem: true,
    confidence: "estimate",
    note: "Tandem anti-armor. Public figures are claims; 1200 mm is inside the usual quoted band.",
  }),
  R("javelin", "FGM-148 Javelin", "USA", 1996, "modern", "Javelin", "heat", 127, 8.4, 300, {
    heatPenMm: 760,
    tandem: true,
    confidence: "estimate",
    note: "Top-attack is the design shot. Direct-attack mode is what this row fires. Put a roof plate in the builder for the top attack.",
  }),
  R("spike", "Spike-LR", "Israel", 1997, "modern", "Spike", "heat", 130, 13, 180, {
    heatPenMm: 700,
    tandem: true,
    confidence: "estimate",
  }),
  R("kornet", "9M133 Kornet", "Russia", 1998, "modern", "Kornet", "heat", 152, 27, 250, {
    heatPenMm: 1200,
    tandem: true,
    confidence: "estimate",
    note: "Manufacturer claim is 1000–1200 mm behind ERA. Stored as a claim.",
  }),
  R("kornet-d", "9M133M Kornet-M", "Russia", 2012, "modern", "Kornet-M", "heat", 152, 31, 300, {
    heatPenMm: 1300,
    tandem: true,
    confidence: "estimate",
    note: "Manufacturer claim, tandem thermobaric and HEAT variants exist; this is the HEAT claim.",
  }),
  R("refleks", "9M119M Refleks", "USSR", 1985, "coldwar", "9K119", "heat", 125, 17, 340, {
    heatPenMm: 700,
    tandem: true,
    confidence: "estimate",
    note: "Gun-launched. Later Invar-class tandem.",
  }),
  R("refleks-m", "9M119M1 Invar-M", "Russia", 1990, "modern", "Refleks", "heat", 125, 17.2, 350, {
    heatPenMm: 900,
    tandem: true,
    confidence: "estimate",
  }),
  R("bill2", "RBS 56 BILL 2", "Sweden", 1999, "modern", "BILL 2", "heat", 130, 10.5, 200, {
    heatPenMm: 500,
    tandem: true,
    confidence: "estimate",
    note: "Overfly top attack. Use it on a roof coupon.",
  }),
  R("stugna", "Stugna-P", "Ukraine", 2011, "modern", "RK-2S", "heat", 130, 29, 220, {
    heatPenMm: 800,
    tandem: true,
    confidence: "estimate",
  }),
  R("hj8", "HJ-8", "China", 1984, "coldwar", "Hongjian-8", "heat", 120, 11, 220, {
    heatPenMm: 600,
    confidence: "estimate",
  }),
  R("hj12", "HJ-12", "China", 2014, "modern", "Hongjian-12", "heat", 135, 17, 200, {
    heatPenMm: 1100,
    tandem: true,
    confidence: "estimate",
    note: "Fire-and-forget claim. Top or direct; this row is direct HEAT.",
  }),

  // ——— Artillery & leftovers people will look for ———
  R("25pdr", "25-pounder AP", "Britain", 1940, "ww2", "25-pdr", "ap", 87.6, 9.1, 610, {
    ...rep(70, "Field gun pressed into anti-tank work."),
  }),
  R("105-m67", "105 mm M67 HEAT", "USA", 1944, "ww2", "105 mm M4 howitzer", "heat", 105, 13, 380, {
    heatPenMm: 100,
    confidence: "representative",
    note: "Early howitzer HEAT. Modest.",
  }),
  R("155-bonus", "155 mm BONUS", "France / Sweden", 2000, "modern", "155 mm", "ap", 155, 6.5, 500, {
    quality: 0.4,
    confidence: "calculated",
    note: "Sensor-fuzed submunition, not a gun AP round. The model can only treat the slug as a crude kinetic; do not quote it.",
  }),
  R("155-heat", "155 mm M712 Copperhead", "USA", 1982, "coldwar", "155 mm", "heat", 155, 62, 450, {
    heatPenMm: 500,
    confidence: "estimate",
    note: "Laser-guided HEAT shell. Public penetration is an estimate.",
  }),
  R("203-he", "8-inch M106 HE", "USA", 1940, "ww2", "M1 howitzer", "he", 203, 90, 590, {
    quality: 0.25,
    confidence: "calculated",
    note: "Shell-body only. Cratering and blast are outside the model.",
  }),
];

export function ammoById(id: string): Ammo | undefined {
  return AMMUNITION.find((a) => a.id === id);
}

export const TYPE_LABEL: Record<AmmoType, string> = {
  shot: "Round shot",
  ap: "AP",
  apbc: "APBC",
  apcbc: "APCBC",
  apcr: "APCR / HVAP",
  apds: "APDS",
  apfsds: "APFSDS",
  heat: "HEAT",
  hesh: "HESH",
  he: "HE body",
};

export const CONFIDENCE_LABEL: Record<Confidence, string> = {
  published: "Published table",
  representative: "Cited figure",
  estimate: "Open estimate",
  calculated: "Formula only",
};
