export type Era =
  | "ancient"
  | "blackpowder"
  | "ironclad"
  | "ww1"
  | "interwar"
  | "ww2"
  | "coldwar"
  | "modern";

export type AmmoType =
  | "shot"
  | "ap"
  | "apbc"
  | "apcbc"
  | "apcr"
  | "apds"
  | "apfsds"
  | "heat"
  | "hesh"
  | "he";

export type Core = "steel" | "tungsten" | "du" | "wc" | "iron" | "lead";

export type Confidence = "published" | "representative" | "estimate" | "calculated";

export type MaterialId =
  | "rha"
  | "hhs"
  | "fha"
  | "cast"
  | "mild"
  | "wrought"
  | "sts"
  | "wood"
  | "aluminum"
  | "textolite"
  | "rubber"
  | "ceramic"
  | "nera"
  | "titanium"
  | "concrete"
  | "bronze"
  | "leather"
  | "air"
  | "era-k1"
  | "era-k5"
  | "era-relikt"
  | "era-blazer"
  | "era-heavy";

export type Ammo = {
  id: string;
  name: string;
  nation: string;
  year: number;
  era: Era;
  gun: string;
  type: AmmoType;
  /** Bore or body diameter, mm. */
  caliberMm: number;
  /** Penetrating mass, kg (core mass for subcaliber rounds). */
  massKg: number;
  /** Full in-flight mass if different (sabot + core). */
  flightMassKg?: number;
  velocityMs: number;
  /** Velocity e-folding distance, metres. */
  tau?: number;
  /** De Marre multiplier when no anchor or table exists. */
  quality?: number;
  /** Diameter of the penetrator. Defaults to caliber. */
  penD?: number;
  rodLengthMm?: number;
  rodDiameterMm?: number;
  core?: Core;
  /** Vertical RHA perforation at `anchorVelocityMs` (or muzzle). */
  anchorPenMm?: number;
  anchorVelocityMs?: number;
  /** [range m, vertical RHA mm]. */
  table?: [number, number][];
  heatPenMm?: number;
  /** Built-in jet standoff, charge diameters. */
  standoffCd?: number;
  tandem?: boolean;
  confidence: Confidence;
  note?: string;
  custom?: boolean;
};

export type Layer = {
  material: MaterialId;
  thicknessMm: number;
};

export type Place =
  | "glacis"
  | "lfp"
  | "hull-side"
  | "hull-rear"
  | "turret-front"
  | "mantlet"
  | "turret-side"
  | "turret-rear"
  | "roof"
  | "belt"
  | "face"
  | "custom";

export type Silhouette = "tank" | "casemate" | "light" | "ship" | "turret" | "wagon" | "coupon";

export type Plate = {
  id: string;
  name: string;
  /** Degrees from vertical. 0 is upright. */
  slopeDeg: number;
  place: Place;
  layers: Layer[];
};

export type Vehicle = {
  id: string;
  name: string;
  nation: string;
  year: number;
  era: Era;
  silhouette: Silhouette;
  confidence: Confidence;
  note: string;
  plates: Plate[];
};

export type Scheme = {
  id: string;
  name: string;
  slopeDeg: number;
  layers: Layer[];
  note?: string;
};

export type Verdict = "perforation" | "partial" | "ricochet" | "spall" | "dud" | "held";

export type LayerLog = {
  index: number;
  material: MaterialId;
  thicknessMm: number;
  eqMm: number;
  outcome: "perforated" | "stopped" | "passed" | "triggered" | "disrupted";
  enterV: number;
  exitV: number;
  note: string;
};

export type ShotResult = {
  verdict: Verdict;
  headline: string;
  summary: string;
  impactV: number;
  residualV: number;
  residualPenMm: number;
  verticalPenMm: number;
  obliquityDeg: number;
  resistanceMm: number;
  losMm: number;
  channelMm: number;
  layers: LayerLog[];
  caveats: string[];
  limitRangeM: number | null;
};
