import { MATERIALS } from "./materials";
import type {
  Ammo,
  AmmoType,
  Layer,
  LayerLog,
  Plate,
  ShotResult,
  Verdict,
} from "./types";

type Profile = {
  base: number;
  breakAt: number;
  breakGain: number;
  ricochet: number;
  vExp: number;
  tau: number;
};

const PROFILES: Record<AmmoType, Profile> = {
  shot: { base: 1.22, breakAt: 42, breakGain: 0.022, ricochet: 64, vExp: 1.4, tau: 2800 },
  ap: { base: 1.12, breakAt: 40, breakGain: 0.026, ricochet: 70, vExp: 1.4, tau: 7200 },
  apbc: { base: 1.06, breakAt: 42, breakGain: 0.022, ricochet: 72, vExp: 1.4, tau: 8000 },
  apcbc: { base: 1.02, breakAt: 44, breakGain: 0.02, ricochet: 74, vExp: 1.4, tau: 8800 },
  apcr: { base: 1.28, breakAt: 36, breakGain: 0.032, ricochet: 63, vExp: 1.55, tau: 4200 },
  apds: { base: 1.22, breakAt: 40, breakGain: 0.026, ricochet: 70, vExp: 1.28, tau: 9500 },
  apfsds: { base: 1.05, breakAt: 62, breakGain: 0.012, ricochet: 81, vExp: 1.12, tau: 17000 },
  heat: { base: 1.18, breakAt: 58, breakGain: 0.018, ricochet: 78, vExp: 0.15, tau: 7000 },
  hesh: { base: 1, breakAt: 80, breakGain: 0, ricochet: 75, vExp: 0.1, tau: 5500 },
  he: { base: 1.28, breakAt: 38, breakGain: 0.03, ricochet: 58, vExp: 1.15, tau: 6000 },
};

const RHO: Record<string, number> = {
  tungsten: 17.6,
  du: 18.6,
  wc: 14.7,
  steel: 7.85,
  iron: 7.2,
  lead: 11.3,
};

export function profileOf(type: AmmoType): Profile {
  return PROFILES[type];
}

export function tauOf(ammo: Ammo): number {
  return ammo.tau ?? PROFILES[ammo.type].tau;
}

export function velocityAt(v0: number, tau: number, rangeM: number): number {
  return v0 * Math.exp(-Math.max(0, rangeM) / Math.max(200, tau));
}

export function obliquityDeg(slopeFromVertical: number, yawDeg: number): number {
  const c =
    Math.cos((slopeFromVertical * Math.PI) / 180) * Math.cos((yawDeg * Math.PI) / 180);
  return (Math.acos(Math.min(1, Math.max(-1, c))) * 180) / Math.PI;
}

export function demarreMm(massKg: number, vMs: number, diameterMm: number): number {
  if (massKg <= 0 || vMs <= 0 || diameterMm <= 0) return 0;
  return (
    (0.1345 * Math.pow(massKg, 0.71) * Math.pow(vMs, 1.4)) / Math.pow(diameterMm, 0.869)
  );
}

function rodShapeMm(ammo: Ammo, v: number): number {
  const L = ammo.rodLengthMm ?? Math.max(ammo.caliberMm * 4, 80);
  const D = ammo.rodDiameterMm ?? ammo.penD ?? Math.max(8, ammo.caliberMm * 0.22);
  const core = ammo.core ?? "tungsten";
  const rho = RHO[core] ?? 17.6;
  const ld = Math.max(2, L / Math.max(1, D));
  const a = core === "du" ? 1.02 : core === "steel" ? 0.7 : core === "wc" ? 0.86 : core === "iron" ? 0.62 : 0.94;
  const hydro = a * (1 / Math.tanh(0.283 + 0.0656 * ld)) * Math.sqrt(rho / 7.85);
  const b = core === "steel" || core === "iron" ? 1280 : core === "wc" ? 1100 : 980;
  const vel = Math.exp(-Math.pow(b / Math.max(80, v), 2));
  return L * hydro * vel;
}

function tablePen(ammo: Ammo, v: number): number | null {
  const table = ammo.table;
  if (!table || table.length === 0) return null;
  const tau = tauOf(ammo);
  const exp = PROFILES[ammo.type].vExp || 1.4;
  const pts = table
    .map(([r, p]) => ({ v: velocityAt(ammo.velocityMs, tau, r), p }))
    .sort((a, b) => a.v - b.v);
  if (v <= pts[0]!.v) return pts[0]!.p * Math.pow(v / Math.max(1, pts[0]!.v), exp);
  const last = pts[pts.length - 1]!;
  if (v >= last.v) return last.p * Math.pow(v / Math.max(1, last.v), exp);
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i]!;
    const b = pts[i + 1]!;
    if (v >= a.v && v <= b.v) {
      const t = (v - a.v) / Math.max(1e-6, b.v - a.v);
      return a.p + t * (b.p - a.p);
    }
  }
  return last.p;
}

/** Vertical RHA perforation (mm) at an impact speed. */
export function verticalPenMm(ammo: Ammo, v: number): number {
  if (ammo.type === "heat") return ammo.heatPenMm ?? ammo.anchorPenMm ?? 0;
  if (ammo.type === "hesh") return 0;
  const fromTable = tablePen(ammo, v);
  if (fromTable != null) return Math.max(0, fromTable);
  const shape = ammo.type === "apfsds" ? rodShapeMm(ammo, v) : demarreMm(ammo.massKg, v, ammo.penD ?? ammo.caliberMm);
  if (ammo.anchorPenMm && ammo.anchorPenMm > 0) {
    const vA = ammo.anchorVelocityMs ?? ammo.velocityMs;
    const shapeA =
      ammo.type === "apfsds"
        ? rodShapeMm(ammo, vA)
        : demarreMm(ammo.massKg, vA, ammo.penD ?? ammo.caliberMm);
    if (shapeA > 1e-6) return ammo.anchorPenMm * (shape / shapeA);
  }
  return shape * (ammo.quality ?? 1);
}

function slopeExponent(type: AmmoType, theta: number): number {
  const p = PROFILES[type];
  if (theta <= p.breakAt) return p.base;
  return p.base + (theta - p.breakAt) * p.breakGain;
}

function cosPow(thetaDeg: number, n: number): number {
  const c = Math.cos((Math.min(88, thetaDeg) * Math.PI) / 180);
  return Math.pow(Math.max(0.035, c), n);
}

export function plateLosMm(layers: Layer[], slopeDeg: number): number {
  const c = Math.cos((Math.min(88, slopeDeg) * Math.PI) / 180);
  const t = layers.reduce((s, l) => s + (MATERIALS[l.material].air ? 0 : l.thicknessMm), 0);
  return t / Math.max(0.035, c);
}

export function resistanceMm(layers: Layer[], ammo: Ammo, slopeDeg: number, yawDeg: number): number {
  const theta = obliquityDeg(slopeDeg, yawDeg);
  const n = slopeExponent(ammo.type, theta);
  const c = cosPow(theta, n);
  let eq = 0;
  for (const layer of layers) {
    const mat = MATERIALS[layer.material];
    if (mat.air || mat.era) continue;
    const thick = mat.skinMm != null ? Math.min(layer.thicknessMm, mat.skinMm) : layer.thicknessMm;
    const fac = ammo.type === "heat" ? mat.heat : mat.ke;
    eq += (thick * fac) / c;
  }
  return eq;
}

function heatStandoffFactor(standoffMm: number, caliber: number): number {
  const cd = standoffMm / Math.max(1, caliber);
  if (cd < 1.2) return 0.72 + 0.28 * (cd / 1.2);
  if (cd <= 6.5) return 1;
  return Math.exp(-(cd - 6.5) / 7.5);
}

function ricochetLimit(ammo: Ammo, v: number, firstThick: number): number {
  const p = PROFILES[ammo.type];
  let limit = p.ricochet;
  if (v < 700) limit -= ((700 - v) / 700) * 14;
  const d = ammo.penD ?? ammo.rodDiameterMm ?? ammo.caliberMm;
  if (firstThick > 0 && d > firstThick * 2.4 && ammo.type !== "apcr" && ammo.type !== "heat") {
    limit += 10;
  }
  return limit;
}

function emptyResult(partial: Omit<ShotResult, "layers" | "caveats"> & { layers?: LayerLog[]; caveats?: string[] }): ShotResult {
  return { layers: [], caveats: [], ...partial };
}

export function limitRangeM(ammo: Ammo, layers: Layer[], slopeDeg: number, yawDeg: number): number | null {
  if (ammo.type === "hesh") return null;
  const resist = resistanceMm(layers, ammo, slopeDeg, yawDeg);
  if (resist <= 0) return 0;
  // Binary search the range where vertical pen equals simple resistance.
  // ERA and air make the full sim the authority; this is the monolithic estimate.
  let lo = 0;
  let hi = ammo.type === "shot" ? 4000 : 12000;
  const p0 = verticalPenMm(ammo, ammo.velocityMs);
  if (p0 < resist && ammo.type !== "heat") return null;
  if (ammo.type === "heat") return p0 >= resist ? hi : null;
  for (let i = 0; i < 18; i++) {
    const mid = (lo + hi) / 2;
    const v = velocityAt(ammo.velocityMs, tauOf(ammo), mid);
    if (verticalPenMm(ammo, v) >= resist) lo = mid;
    else hi = mid;
  }
  return lo > 11500 ? null : Math.round(lo);
}

export function simulate(
  layers: Layer[],
  slopeDeg: number,
  ammo: Ammo,
  rangeM: number,
  yawDeg: number,
  velocityOverride?: number | null,
): ShotResult {
  const theta = obliquityDeg(slopeDeg, yawDeg);
  const impactV =
    velocityOverride != null && velocityOverride > 0
      ? velocityOverride
      : velocityAt(ammo.velocityMs, tauOf(ammo), rangeM);
  const los = plateLosMm(layers, theta);
  const resist = resistanceMm(layers, ammo, slopeDeg, yawDeg);
  const caveats: string[] = [];

  if (ammo.confidence === "estimate") {
    caveats.push("Round figures are open-source estimates, not a classified proof table.");
  }
  if (ammo.type === "apds" && ammo.year < 1960) {
    caveats.push("Early APDS often shattered or flew crooked. This result is the tidy ballistic number, not the messy trial.");
  }
  const composite = layers.some((l) =>
    ["nera", "ceramic", "textolite", "era-k1", "era-k5", "era-relikt", "era-blazer", "era-heavy"].includes(
      l.material,
    ),
  );
  if (composite && (ammo.type === "ap" || ammo.type === "apcbc" || ammo.type === "shot" || ammo.type === "he")) {
    caveats.push(
      "RHAe measured against long rods does not transfer cleanly to a full-caliber shell. Treat a mixed result as a sketch.",
    );
  }
  if (Math.abs(theta - ricochetLimit(ammo, impactV, layers.find((l) => !MATERIALS[l.material].air)?.thicknessMm ?? 80)) < 6) {
    caveats.push("Within a few degrees of ricochet. Real yaw and plate wander would mix bounces and bites.");
  }

  if (ammo.type === "hesh") return simulateHesh(layers, ammo, theta, impactV, los, resist, caveats);
  if (ammo.type === "heat") return simulateHeat(layers, ammo, theta, impactV, los, resist, rangeM, yawDeg, slopeDeg, caveats);
  if (ammo.type === "apfsds") return simulateRod(layers, ammo, theta, impactV, los, resist, rangeM, yawDeg, slopeDeg, caveats);
  return simulateRigid(layers, ammo, theta, impactV, los, resist, rangeM, yawDeg, slopeDeg, caveats);
}

function headline(verdict: Verdict, residualV: number): string {
  if (verdict === "perforation") return "Armor defeated";
  if (verdict === "partial") return "Stopped in the stack";
  if (verdict === "ricochet") return "Ricochet";
  if (verdict === "spall") return "Spall defeat";
  if (verdict === "dud") return "Dud";
  return residualV > 0 ? "Through" : "Armor held";
}

function simulateHesh(
  layers: Layer[],
  ammo: Ammo,
  theta: number,
  impactV: number,
  los: number,
  resist: number,
  caveats: string[],
): ShotResult {
  const base = {
    impactV,
    residualV: 0,
    residualPenMm: 0,
    verticalPenMm: 0,
    obliquityDeg: theta,
    resistanceMm: resist,
    losMm: los,
    channelMm: 0,
    limitRangeM: null as number | null,
  };
  if (impactV < 180) {
    return emptyResult({
      ...base,
      verdict: "dud",
      headline: "Dud",
      summary: "Too slow for the squash head to form a pat.",
      caveats,
    });
  }
  if (theta > 72) {
    return emptyResult({
      ...base,
      verdict: "ricochet",
      headline: "Ricochet",
      summary: "Graze angle. The plastic explosive never makes a proper pat.",
      caveats,
    });
  }
  const disruptive = layers.some((l) => {
    const m = MATERIALS[l.material];
    if (m.air && l.thicknessMm > 25) return true;
    if (m.era) return true;
    return ["nera", "ceramic", "textolite"].includes(l.material) && l.thicknessMm > 15;
  });
  let steel = 0;
  let castBonus = false;
  for (let i = layers.length - 1; i >= 0; i--) {
    const layer = layers[i]!;
    const m = MATERIALS[layer.material];
    if (m.air || m.era) break;
    if (["rha", "hhs", "fha", "cast", "mild", "sts", "wrought"].includes(layer.material)) {
      steel += layer.thicknessMm;
      if (layer.material === "cast") castBonus = true;
    } else break;
  }
  const limit = ammo.caliberMm * (ammo.caliberMm >= 100 ? 1.45 : 1.08) * (castBonus ? 1.18 : 1);
  if (disruptive) {
    caveats.push("HESH needs a thick monolithic steel back. Spaced plates, ceramics, and ERA were built to ruin it.");
    return emptyResult({
      ...base,
      verdict: "held",
      headline: "Armor held",
      summary: "The pat detonates, but the array breaks up the shock before a lethal scab can form.",
      caveats,
    });
  }
  if (steel > 0 && steel <= limit) {
    return emptyResult({
      ...base,
      verdict: "spall",
      headline: "Spall defeat",
      summary: `Monolithic steel ${Math.round(steel)} mm is inside the scab window (about ${Math.round(limit)} mm for this round). The plate is not holed; the inside face comes off.`,
      caveats,
      channelMm: steel,
    });
  }
  return emptyResult({
    ...base,
    verdict: "held",
    headline: "Armor held",
    summary:
      steel === 0
        ? "No continuous steel backplate for a scab to form from."
        : `Backplate ${Math.round(steel)} mm is thicker than this HESH can scab (about ${Math.round(limit)} mm).`,
    caveats,
  });
}

function simulateHeat(
  layers: Layer[],
  ammo: Ammo,
  theta: number,
  impactV: number,
  los: number,
  resist: number,
  rangeM: number,
  yawDeg: number,
  slopeDeg: number,
  caveats: string[],
): ShotResult {
  const logs: LayerLog[] = [];
  if (impactV < 120) {
    return {
      verdict: "dud",
      headline: "Dud",
      summary: "Impact is below the fuze window.",
      impactV,
      residualV: 0,
      residualPenMm: 0,
      verticalPenMm: ammo.heatPenMm ?? 0,
      obliquityDeg: theta,
      resistanceMm: resist,
      losMm: los,
      channelMm: 0,
      layers: logs,
      caveats,
      limitRangeM: null,
    };
  }
  const firstHard = layers.find((l) => !MATERIALS[l.material].air);
  const limit = ricochetLimit(ammo, impactV, firstHard?.thicknessMm ?? 40);
  if (theta > limit) {
    return {
      verdict: "ricochet",
      headline: "Ricochet",
      summary: `Obliquity ${theta.toFixed(0)}° is past the graze limit (~${limit.toFixed(0)}°). The jet does not couple.`,
      impactV,
      residualV: 0,
      residualPenMm: ammo.heatPenMm ?? 0,
      verticalPenMm: ammo.heatPenMm ?? 0,
      obliquityDeg: theta,
      resistanceMm: resist,
      losMm: los,
      channelMm: 0,
      layers: [],
      caveats,
      limitRangeM: null,
    };
  }
  let remaining = ammo.heatPenMm ?? ammo.anchorPenMm ?? 0;
  let standoff = ammo.caliberMm * (ammo.standoffCd ?? 2.6);
  let detonated = false;
  let precursor = false;
  let channel = 0;
  const n = slopeExponent("heat", theta);
  const c = cosPow(theta, n);

  for (let i = 0; i < layers.length; i++) {
    const layer = layers[i]!;
    const mat = MATERIALS[layer.material];
    if (mat.air) {
      if (detonated) {
        const before = heatStandoffFactor(standoff, ammo.caliberMm);
        standoff += layer.thicknessMm;
        const after = heatStandoffFactor(standoff, ammo.caliberMm);
        remaining *= after / Math.max(0.05, before);
      }
      logs.push({
        index: i,
        material: layer.material,
        thicknessMm: layer.thicknessMm,
        eqMm: 0,
        outcome: "passed",
        enterV: impactV,
        exitV: impactV,
        note: detonated ? `Standoff grows to ${(standoff / ammo.caliberMm).toFixed(1)} CD.` : "Gap ahead of the fuze.",
      });
      channel += layer.thicknessMm;
      continue;
    }
    if (mat.era) {
      detonated = true;
      if (ammo.tandem && !precursor) {
        precursor = true;
        logs.push({
          index: i,
          material: layer.material,
          thicknessMm: layer.thicknessMm,
          eqMm: mat.skinMm ?? 6,
          outcome: "triggered",
          enterV: impactV,
          exitV: impactV,
          note: "Precursor expends the cassette. Main charge is intact.",
        });
      } else {
        const remain = mat.era?.heatRemain ?? 0.4;
        remaining *= remain;
        logs.push({
          index: i,
          material: layer.material,
          thicknessMm: layer.thicknessMm,
          eqMm: mat.skinMm ?? 6,
          outcome: "triggered",
          enterV: impactV,
          exitV: impactV,
          note: `Jet reduced to ${Math.round(remain * 100)}% by the cassette.`,
        });
      }
      const skin = mat.skinMm ?? 6;
      const skinEq = (skin * 1) / c;
      if (remaining <= skinEq) {
        logs.push({
          index: i,
          material: layer.material,
          thicknessMm: skin,
          eqMm: skinEq,
          outcome: "stopped",
          enterV: impactV,
          exitV: 0,
          note: "The damaged jet dies in the cassette skin.",
        });
        channel += layer.thicknessMm * 0.5;
        return finishHeat("partial", logs, ammo, impactV, theta, resist, los, channel, remaining, layers, slopeDeg, yawDeg, caveats);
      }
      remaining -= skinEq;
      channel += layer.thicknessMm;
      continue;
    }
    detonated = true;
    const fac = mat.heat;
    const eq = (layer.thicknessMm * fac) / c;
    if (remaining > eq) {
      remaining -= eq;
      channel += layer.thicknessMm;
      logs.push({
        index: i,
        material: layer.material,
        thicknessMm: layer.thicknessMm,
        eqMm: eq,
        outcome: "perforated",
        enterV: impactV,
        exitV: impactV,
        note: `Jet spends ${Math.round(eq)} mm RHAe. ${Math.round(remaining)} mm remain.`,
      });
    } else {
      const frac = eq > 0 ? remaining / eq : 1;
      channel += layer.thicknessMm * frac;
      logs.push({
        index: i,
        material: layer.material,
        thicknessMm: layer.thicknessMm,
        eqMm: eq,
        outcome: "stopped",
        enterV: impactV,
        exitV: 0,
        note: `Jet stops ${Math.round(frac * 100)}% of the way through this layer.`,
      });
      return finishHeat("partial", logs, ammo, impactV, theta, resist, los, channel, 0, layers, slopeDeg, yawDeg, caveats);
    }
  }
  return finishHeat("perforation", logs, ammo, impactV, theta, resist, los, channel, remaining, layers, slopeDeg, yawDeg, caveats);
}

function finishHeat(
  verdict: Verdict,
  logs: LayerLog[],
  ammo: Ammo,
  impactV: number,
  theta: number,
  resist: number,
  los: number,
  channel: number,
  remaining: number,
  layers: Layer[],
  slopeDeg: number,
  yawDeg: number,
  caveats: string[],
): ShotResult {
  const summary =
    verdict === "perforation"
      ? `Shaped charge clears the array with about ${Math.round(remaining)} mm of jet to spare.`
      : "The jet is consumed inside the array.";
  return {
    verdict,
    headline: headline(verdict, 0),
    summary,
    impactV,
    residualV: verdict === "perforation" ? impactV * 0.15 : 0,
    residualPenMm: Math.max(0, remaining),
    verticalPenMm: ammo.heatPenMm ?? 0,
    obliquityDeg: theta,
    resistanceMm: resist,
    losMm: los,
    channelMm: channel,
    layers: logs,
    caveats,
    limitRangeM: limitRangeM(ammo, layers, slopeDeg, yawDeg),
  };
}

function simulateRod(
  layers: Layer[],
  ammo: Ammo,
  theta: number,
  impactV: number,
  los: number,
  resist: number,
  rangeM: number,
  yawDeg: number,
  slopeDeg: number,
  caveats: string[],
): ShotResult {
  const logs: LayerLog[] = [];
  const firstHard = layers.find((l) => !MATERIALS[l.material].air);
  const limit = ricochetLimit(ammo, impactV, firstHard?.thicknessMm ?? 40);
  const vPen0 = verticalPenMm(ammo, impactV);
  if (theta > limit) {
    return {
      verdict: "ricochet",
      headline: "Ricochet",
      summary: `Obliquity ${theta.toFixed(0)}° exceeds the rod's bite (~${limit.toFixed(0)}°).`,
      impactV,
      residualV: impactV * 0.9,
      residualPenMm: vPen0,
      verticalPenMm: vPen0,
      obliquityDeg: theta,
      resistanceMm: resist,
      losMm: los,
      channelMm: 0,
      layers: [],
      caveats,
      limitRangeM: null,
    };
  }
  let health = 1;
  let scale = 1;
  let v = impactV;
  let channel = 0;
  let yawed = false;
  const n = slopeExponent("apfsds", theta);
  const c = cosPow(theta, n);

  const penNow = () => verticalPenMm(ammo, v) * health * scale;

  for (let i = 0; i < layers.length; i++) {
    const layer = layers[i]!;
    const mat = MATERIALS[layer.material];
    if (mat.air) {
      const next = layers[i + 1];
      if (!yawed && layer.thicknessMm > 180 && i > 0) {
        const prev = layers[i - 1]!;
        const rodD = ammo.rodDiameterMm ?? ammo.penD ?? 24;
        if (prev.thicknessMm < rodD * 2.2 && !MATERIALS[prev.material].air) {
          health *= 0.92;
          yawed = true;
        }
      }
      logs.push({
        index: i,
        material: layer.material,
        thicknessMm: layer.thicknessMm,
        eqMm: 0,
        outcome: "passed",
        enterV: v,
        exitV: v,
        note: yawed && layer.thicknessMm > 180 ? "Gap lets the rod yaw after the bumper." : "Air.",
      });
      channel += layer.thicknessMm;
      void next;
      continue;
    }
    if (mat.era) {
      const remain = mat.era?.keRemain ?? 0.8;
      health *= remain;
      logs.push({
        index: i,
        material: layer.material,
        thicknessMm: layer.thicknessMm,
        eqMm: mat.skinMm ?? 8,
        outcome: "triggered",
        enterV: v,
        exitV: v,
        note: `Cassette cuts remaining rod to ${Math.round(remain * 100)}%.`,
      });
      channel += layer.thicknessMm;
      continue;
    }
    const eq = (layer.thicknessMm * mat.ke) / c;
    const p = penNow();
    const enter = v;
    if (p > eq && health > 0.02) {
      const full = verticalPenMm(ammo, v) * scale;
      health -= full > 0 ? eq / full : 1;
      health = Math.max(0, health);
      v *= 1 - 0.06 * Math.min(1, eq / Math.max(1, p));
      channel += layer.thicknessMm;
      logs.push({
        index: i,
        material: layer.material,
        thicknessMm: layer.thicknessMm,
        eqMm: eq,
        outcome: "perforated",
        enterV: enter,
        exitV: v,
        note: `Rod spends ${Math.round((1 - health) * 100)}% of its length so far. Exit ${Math.round(v)} m/s.`,
      });
    } else {
      const frac = eq > 0 ? Math.min(1, p / eq) : 1;
      channel += layer.thicknessMm * frac;
      logs.push({
        index: i,
        material: layer.material,
        thicknessMm: layer.thicknessMm,
        eqMm: eq,
        outcome: "stopped",
        enterV: enter,
        exitV: 0,
        note: `Rod is consumed ${Math.round(frac * 100)}% of the way into this layer.`,
      });
      return {
        verdict: "partial",
        headline: "Stopped in the stack",
        summary: `The rod dies inside ${mat.name.toLowerCase()} with no residual length.`,
        impactV,
        residualV: 0,
        residualPenMm: 0,
        verticalPenMm: vPen0,
        obliquityDeg: theta,
        resistanceMm: resist,
        losMm: los,
        channelMm: channel,
        layers: logs,
        caveats,
        limitRangeM: limitRangeM(ammo, layers, slopeDeg, yawDeg),
      };
    }
  }
  const residualPen = penNow();
  return {
    verdict: "perforation",
    headline: "Armor defeated",
    summary: `Rod exits at ${Math.round(v)} m/s with about ${Math.round(residualPen)} mm of vertical RHA still in it.`,
    impactV,
    residualV: v,
    residualPenMm: residualPen,
    verticalPenMm: vPen0,
    obliquityDeg: theta,
    resistanceMm: resist,
    losMm: los,
    channelMm: channel,
    layers: logs,
    caveats,
    limitRangeM: limitRangeM(ammo, layers, slopeDeg, yawDeg),
  };
}

function simulateRigid(
  layers: Layer[],
  ammo: Ammo,
  theta: number,
  impactV: number,
  los: number,
  resist: number,
  rangeM: number,
  yawDeg: number,
  slopeDeg: number,
  caveats: string[],
): ShotResult {
  const logs: LayerLog[] = [];
  const firstHard = layers.find((l) => !MATERIALS[l.material].air && !MATERIALS[l.material].era);
  const limit = ricochetLimit(ammo, impactV, firstHard?.thicknessMm ?? 40);
  const vPen0 = verticalPenMm(ammo, impactV);
  if (theta > limit && ammo.type !== "he") {
    return {
      verdict: "ricochet",
      headline: "Ricochet",
      summary: `Obliquity ${theta.toFixed(0)}° is past this shell's bite (~${limit.toFixed(0)}°) at ${Math.round(impactV)} m/s.`,
      impactV,
      residualV: impactV * 0.85,
      residualPenMm: vPen0,
      verticalPenMm: vPen0,
      obliquityDeg: theta,
      resistanceMm: resist,
      losMm: los,
      channelMm: Math.min(8, firstHard?.thicknessMm ?? 0),
      layers: [],
      caveats,
      limitRangeM: null,
    };
  }
  let v = impactV;
  let scale = 1;
  let capOn = ammo.type === "apcbc" || ammo.type === "apbc";
  let channel = 0;
  const n = slopeExponent(ammo.type, theta);
  const c = cosPow(theta, n);
  const vExp = PROFILES[ammo.type].vExp || 1.4;
  const fhaExtra = ammo.type === "ap" || ammo.type === "shot" ? 1.18 : ammo.type === "apcr" ? 1.05 : 0.96;
  const bore = ammo.penD ?? ammo.caliberMm;
  if (ammo.type === "apcr" && theta > 52) scale *= 0.82;

  for (let i = 0; i < layers.length; i++) {
    const layer = layers[i]!;
    const mat = MATERIALS[layer.material];
    if (mat.air) {
      if (capOn && i > 0) {
        capOn = false;
        scale *= 0.9;
      }
      logs.push({
        index: i,
        material: layer.material,
        thicknessMm: layer.thicknessMm,
        eqMm: 0,
        outcome: "passed",
        enterV: v,
        exitV: v,
        note: capOn ? "Air." : "Cap stripped in the gap.",
      });
      channel += layer.thicknessMm;
      continue;
    }
    if (mat.era) {
      const remain = mat.era?.keRemain ?? 0.95;
      scale *= remain;
      logs.push({
        index: i,
        material: layer.material,
        thicknessMm: layer.thicknessMm,
        eqMm: mat.skinMm ?? 6,
        outcome: "triggered",
        enterV: v,
        exitV: v,
        note:
          remain > 0.9
            ? "Light ERA. Full-caliber shot barely notices."
            : `Cassette cuts remaining penetration to ${Math.round(remain * 100)}%.`,
      });
      channel += layer.thicknessMm;
      continue;
    }
    let fac = mat.ke;
    if (layer.material === "fha") fac *= capOn ? 0.94 : fhaExtra;
    if (
      bore > layer.thicknessMm * 3 &&
      (ammo.type === "ap" || ammo.type === "apcbc" || ammo.type === "apbc" || ammo.type === "shot")
    ) {
      fac *= Math.max(0.62, 1 - (bore / layer.thicknessMm - 3) * 0.06);
    }
    const eq = (layer.thicknessMm * fac) / c;
    const p = verticalPenMm(ammo, v) * scale;
    const enter = v;
    if (p <= 1 || v < 40) {
      logs.push({
        index: i,
        material: layer.material,
        thicknessMm: layer.thicknessMm,
        eqMm: eq,
        outcome: "stopped",
        enterV: enter,
        exitV: 0,
        note: "No meaningful residual energy.",
      });
      return rigidFinish("partial", logs, ammo, impactV, vPen0, theta, resist, los, channel, 0, 0, layers, slopeDeg, yawDeg, caveats);
    }
    const vbl = v * Math.pow(eq / Math.max(p, 1e-3), 1 / vExp);
    if (v > vbl) {
      const v2 = v * v - vbl * vbl;
      v = Math.sqrt(Math.max(0, v2));
      if (layer.thicknessMm < bore * 0.25) {
        capOn = false;
      }
      channel += layer.thicknessMm;
      logs.push({
        index: i,
        material: layer.material,
        thicknessMm: layer.thicknessMm,
        eqMm: eq,
        outcome: "perforated",
        enterV: enter,
        exitV: v,
        note: `Ballistic limit ${Math.round(vbl)} m/s. Exits at ${Math.round(v)} m/s.`,
      });
    } else {
      const frac = Math.pow(v / Math.max(1, vbl), vExp);
      channel += layer.thicknessMm * Math.min(1, frac);
      logs.push({
        index: i,
        material: layer.material,
        thicknessMm: layer.thicknessMm,
        eqMm: eq,
        outcome: "stopped",
        enterV: enter,
        exitV: 0,
        note: `Needs ${Math.round(vbl)} m/s against this layer. Buries ${Math.round(frac * 100)}% of the way in.`,
      });
      return rigidFinish("partial", logs, ammo, impactV, vPen0, theta, resist, los, channel, 0, 0, layers, slopeDeg, yawDeg, caveats);
    }
  }
  const residualPen = verticalPenMm(ammo, v) * scale;
  return rigidFinish(
    "perforation",
    logs,
    ammo,
    impactV,
    vPen0,
    theta,
    resist,
    los,
    channel,
    v,
    residualPen,
    layers,
    slopeDeg,
    yawDeg,
    caveats,
  );
}

function rigidFinish(
  verdict: Verdict,
  logs: LayerLog[],
  ammo: Ammo,
  impactV: number,
  vPen0: number,
  theta: number,
  resist: number,
  los: number,
  channel: number,
  residualV: number,
  residualPen: number,
  layers: Layer[],
  slopeDeg: number,
  yawDeg: number,
  caveats: string[],
): ShotResult {
  const summary =
    verdict === "perforation"
      ? `Through at ${Math.round(residualV)} m/s, with about ${Math.round(residualPen)} mm of vertical plate still in the shell.`
      : "The shell stops inside the array.";
  return {
    verdict,
    headline: headline(verdict, residualV),
    summary,
    impactV,
    residualV,
    residualPenMm: residualPen,
    verticalPenMm: vPen0,
    obliquityDeg: theta,
    resistanceMm: resist,
    losMm: los,
    channelMm: channel,
    layers: logs,
    caveats,
    limitRangeM: limitRangeM(ammo, layers, slopeDeg, yawDeg),
  };
}

export function energyJ(massKg: number, v: number): number {
  return 0.5 * massKg * v * v;
}

export function activePlate(plate: Plate): Plate {
  return plate;
}

export const MODEL_NOTE = [
  "Full-caliber shot uses a De Marre curve (mass^0.71 · velocity^1.4 / diameter^0.87) locked to a published or representative vertical-RHA anchor when one exists. Range tables, where shown, are interpolated and then scaled if you override velocity.",
  "Obliquity is steeper than line-of-sight alone past the angle where caps stop normalizing. APCR and early APDS are punished on slope. Long rods are not.",
  "Long rods use a Lanz-Odermatt-style hydrodynamic shape (length, L/D, density, a velocity knee near 1 km/s) scaled so the round hits its anchor at the reference speed. Residual length is what later layers see.",
  "HEAT is a jet budget in RHAe, almost independent of speed, with standoff and a graze limit. Tandem charges spend the first ERA cassette only.",
  "HESH scabs monolithic steel and fails against air gaps, ceramics, and NERA — which is why it left the tank fleet.",
  "Nothing here is a finite-element proof. Classified composite recipes are teaching stacks tuned to a published RHAe band, not measured cutaways. Naval 'RHA' is a transposition, not a tank-plate trial.",
];
