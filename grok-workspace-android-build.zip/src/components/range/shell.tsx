import {
  Crosshair,
  Info,
  Layers3,
  Library,
  Plus,
  Search,
  Trash2,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AMMUNITION, CONFIDENCE_LABEL, TYPE_LABEL } from "@/lib/ballistics/ammunition";
import { MATERIAL_ORDER, MATERIALS } from "@/lib/ballistics/materials";
import {
  MODEL_NOTE,
  energyJ,
  plateLosMm,
  resistanceMm,
  simulate,
  tauOf,
  velocityAt,
  verticalPenMm,
} from "@/lib/ballistics/physics";
import type { Ammo, AmmoType, Era, Layer, MaterialId, Plate, Scheme, ShotResult, Vehicle } from "@/lib/ballistics/types";
import { ERA_LABEL, VEHICLES } from "@/lib/ballistics/vehicles";
import { cn } from "@/lib/cn";
import { SceneHost } from "./scene-host";

const ERAS: Era[] = ["ancient", "blackpowder", "ironclad", "ww1", "interwar", "ww2", "coldwar", "modern"];

const DUELS: { name: string; vehicle: string; plate: string; ammo: string; range: number }[] = [
  { name: "88 vs Sherman", vehicle: "m4late", plate: "glacis", ammo: "88-l56", range: 500 },
  { name: "Pak 40 vs Panther", vehicle: "panther", plate: "glacis", ammo: "75-l48", range: 100 },
  { name: "17-pdr vs Tiger", vehicle: "tiger", plate: "front", ammo: "17-apds", range: 500 },
  { name: "122 vs Tiger II", vehicle: "tiger2", plate: "glacis", ammo: "122-br471b", range: 500 },
  { name: "M111 vs T-72A", vehicle: "t72a", plate: "glacis", ammo: "105-m111", range: 1000 },
  { name: "Mango vs Leo 2A4", vehicle: "leo2a4", plate: "turret", ammo: "125-3bm42", range: 2000 },
  { name: "DM53 vs T-80U", vehicle: "t80u", plate: "glacis", ammo: "120-dm53", range: 2000 },
  { name: "68-pdr vs Warrior", vehicle: "warrior", plate: "belt", ammo: "68pdr", range: 400 },
];

const TEACHING: { name: string; scheme: Scheme }[] = [
  {
    name: "Spaced plate",
    scheme: {
      id: "teach-space",
      name: "Spaced plate",
      slopeDeg: 0,
      layers: [
        { material: "rha", thicknessMm: 15 },
        { material: "air", thicknessMm: 120 },
        { material: "rha", thicknessMm: 80 },
      ],
    },
  },
  {
    name: "NERA cheek",
    scheme: {
      id: "teach-nera",
      name: "NERA cheek",
      slopeDeg: 10,
      layers: [
        { material: "hhs", thicknessMm: 40 },
        { material: "nera", thicknessMm: 300 },
        { material: "rha", thicknessMm: 70 },
      ],
    },
  },
  {
    name: "ERA hull",
    scheme: {
      id: "teach-era",
      name: "ERA over steel",
      slopeDeg: 60,
      layers: [
        { material: "era-k5", thicknessMm: 30 },
        { material: "rha", thicknessMm: 60 },
        { material: "textolite", thicknessMm: 100 },
        { material: "rha", thicknessMm: 50 },
      ],
    },
  },
];

type Mode = "range" | "builder" | "library";
type Catalog = "armor" | "rounds";

function mm(n: number) {
  return `${Math.round(n)} mm`;
}
function ms(n: number) {
  return `${Math.round(n)} m/s`;
}

function loadJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

let audioCtx: AudioContext | null = null;
function playShot(verdict: ShotResult["verdict"], muted: boolean) {
  if (muted || typeof window === "undefined") return;
  const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!audioCtx) audioCtx = new Ctx();
  if (audioCtx.state === "suspended") void audioCtx.resume();
  const t = audioCtx.currentTime;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = "triangle";
  const hot = verdict === "perforation" || verdict === "spall";
  osc.frequency.setValueAtTime(hot ? 160 : 95, t);
  osc.frequency.exponentialRampToValueAtTime(42, t + 0.22);
  gain.gain.setValueAtTime(0.0001, t);
  gain.gain.exponentialRampToValueAtTime(0.09, t + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.32);
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start(t);
  osc.stop(t + 0.34);
}

export function Shell() {
  const [mode, setMode] = useState<Mode>("range");
  const [catalog, setCatalog] = useState<Catalog>("armor");
  const [era, setEra] = useState<Era | "all">("all");
  const [query, setQuery] = useState("");
  const [vehicleId, setVehicleId] = useState("panther");
  const [plateId, setPlateId] = useState("glacis");
  const [ammoId, setAmmoId] = useState("88-l56");
  const [rangeM, setRangeM] = useState(500);
  const [yaw, setYaw] = useState(0);
  const [useOverride, setUseOverride] = useState(false);
  const [override, setOverride] = useState(750);
  const [gain, setGain] = useState(5);
  const [view, setView] = useState<"vehicle" | "section">("vehicle");
  const [muted, setMuted] = useState(false);
  const [about, setAbout] = useState(false);
  const [catalogOpen, setCatalogOpen] = useState(false);
  const [shotToken, setShotToken] = useState(0);
  const [result, setResult] = useState<ShotResult | null>(null);
  const [schemes, setSchemes] = useState<Scheme[]>([]);
  const [customAmmo, setCustomAmmo] = useState<Ammo[]>([]);
  const [draft, setDraft] = useState<Scheme>(TEACHING[0]!.scheme);
  const [batch, setBatch] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setSchemes(loadJson("pg-schemes", []));
    setCustomAmmo(loadJson("pg-ammo", []));
    setMuted(loadJson("pg-muted", false));
    setHydrated(true);
  }, []);
  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem("pg-schemes", JSON.stringify(schemes));
  }, [schemes, hydrated]);
  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem("pg-ammo", JSON.stringify(customAmmo));
  }, [customAmmo, hydrated]);
  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem("pg-muted", JSON.stringify(muted));
  }, [muted, hydrated]);

  const library = useMemo(() => [...AMMUNITION, ...customAmmo], [customAmmo]);
  const vehicle = VEHICLES.find((v) => v.id === vehicleId) ?? VEHICLES[0]!;
  const presetPlate = vehicle.plates.find((p) => p.id === plateId) ?? vehicle.plates[0]!;
  const ammo = library.find((a) => a.id === ammoId) ?? library[0]!;

  const activePlate: Plate =
    mode === "builder"
      ? { id: "draft", name: draft.name, slopeDeg: draft.slopeDeg, place: "custom", layers: draft.layers }
      : presetPlate;
  const activeVehicle: Vehicle | null = mode === "builder" ? null : vehicle;

  const q = query.trim().toLowerCase();
  const vehicles = VEHICLES.filter((v) => {
    if (era !== "all" && v.era !== era) return false;
    if (!q) return true;
    return `${v.name} ${v.nation} ${v.year}`.toLowerCase().includes(q);
  });
  const rounds = library.filter((a) => {
    if (era !== "all" && a.era !== era) return false;
    if (!q) return true;
    return `${a.name} ${a.gun} ${a.nation} ${a.caliberMm} ${TYPE_LABEL[a.type]}`.toLowerCase().includes(q);
  });

  function pickVehicle(v: Vehicle) {
    setVehicleId(v.id);
    setPlateId(v.plates[0]!.id);
    setMode("range");
    setView("vehicle");
    setCatalogOpen(false);
    setResult(null);
  }
  function pickAmmo(a: Ammo) {
    setAmmoId(a.id);
    setMode((m) => (m === "library" ? "range" : m));
    setCatalogOpen(false);
    setResult(null);
  }
  function fire() {
    const shot = simulate(
      activePlate.layers,
      activePlate.slopeDeg,
      ammo,
      rangeM,
      yaw,
      useOverride ? override : null,
    );
    setResult(shot);
    setShotToken((n) => n + 1);
    setView("section");
    playShot(shot.verdict, muted);
  }

  const curve = useMemo(() => {
    const tau = tauOf(ammo);
    const max = ammo.era === "ironclad" || ammo.caliberMm > 200 ? 8000 : ammo.type === "shot" ? 2500 : 3000;
    const step = max > 4000 ? 500 : 250;
    const rows: { r: number; pen: number; resist: number }[] = [];
    const resist = resistanceMm(activePlate.layers, ammo, activePlate.slopeDeg, yaw);
    for (let r = 0; r <= max; r += step) {
      const v = velocityAt(ammo.velocityMs, tau, r);
      rows.push({
        r,
        pen: Math.round(verticalPenMm(ammo, v)),
        resist: Math.round(resist),
      });
    }
    return rows;
  }, [ammo, activePlate, yaw]);

  const batchRows = useMemo(() => {
    if (!batch) return [];
    return library
      .map((a) => {
        const shot = simulate(activePlate.layers, activePlate.slopeDeg, a, rangeM, yaw, null);
        return { ammo: a, shot };
      })
      .sort((a, b) => {
        const score = (s: ShotResult) =>
          s.verdict === "perforation" || s.verdict === "spall" ? 2 : s.verdict === "partial" ? 1 : 0;
        return score(b.shot) - score(a.shot) || b.shot.verticalPenMm - a.shot.verticalPenMm;
      });
  }, [batch, library, activePlate, rangeM, yaw]);

  const impactV = useOverride ? override : velocityAt(ammo.velocityMs, tauOf(ammo), rangeM);
  const defeats = batchRows.filter((r) => r.shot.verdict === "perforation" || r.shot.verdict === "spall").length;

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-bg text-fg">
      <header className="flex h-14 shrink-0 items-center gap-3 border-b border-line px-3 md:px-4">
        <div className="flex items-center gap-2">
          <Mark />
          <div className="leading-none">
            <div className="text-sm font-semibold tracking-[0.16em]">PROVING GROUND</div>
            <div className="mt-1 hidden text-[0.65rem] tracking-wide text-faint sm:block">
              Armor & ammunition laboratory
            </div>
          </div>
        </div>
        <nav className="ml-auto flex items-center gap-1 md:ml-6">
          <Tab on={mode === "range"} onClick={() => setMode("range")} icon={<Crosshair className="size-4" />}>
            Range
          </Tab>
          <Tab on={mode === "builder"} onClick={() => setMode("builder")} icon={<Layers3 className="size-4" />}>
            Builder
          </Tab>
          <Tab on={mode === "library"} onClick={() => { setMode("library"); setCatalog("rounds"); }} icon={<Library className="size-4" />}>
            Library
          </Tab>
        </nav>
        <button
          type="button"
          className="grid size-10 place-items-center rounded-full text-muted hover:bg-surface hover:text-fg"
          onClick={() => setMuted((m) => !m)}
          aria-label={muted ? "Unmute" : "Mute"}
        >
          {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
        </button>
        <button
          type="button"
          className="grid size-10 place-items-center rounded-full text-muted hover:bg-surface hover:text-fg"
          onClick={() => setAbout(true)}
          aria-label="How the model works"
        >
          <Info className="size-4" />
        </button>
      </header>

      <div className="grid min-h-0 flex-1 lg:grid-cols-[300px_minmax(0,1fr)_340px]">
        <aside
          className={cn(
            "z-30 min-h-0 flex-col bg-raised",
            "max-lg:fixed max-lg:inset-0",
            catalogOpen ? "flex" : "max-lg:hidden",
            "lg:flex lg:border-r lg:border-line",
          )}
        >
          <div className="flex items-center justify-between border-b border-line px-3 py-2 lg:hidden">
            <span className="text-sm tracking-wide">Catalog</span>
            <button type="button" className="grid size-10 place-items-center" onClick={() => setCatalogOpen(false)} aria-label="Close catalog">
              <X className="size-4" />
            </button>
          </div>
          <Catalog
            catalog={catalog}
            setCatalog={setCatalog}
            era={era}
            setEra={setEra}
            query={query}
            setQuery={setQuery}
            vehicles={vehicles}
            rounds={rounds}
            vehicleId={vehicleId}
            ammoId={ammoId}
            onVehicle={pickVehicle}
            onAmmo={pickAmmo}
            countAmmo={library.length}
            countVehicles={VEHICLES.length}
          />
        </aside>

        <main className="relative min-h-[42vh] lg:min-h-0">
          <SceneHost
            vehicle={view === "vehicle" ? activeVehicle : null}
            plate={activePlate}
            ammo={ammo}
            gain={gain}
            view={mode === "builder" ? "section" : view}
            shotToken={shotToken}
            result={result}
            onPick={(id) => {
              setPlateId(id);
              setResult(null);
            }}
          />
          <div className="pointer-events-none absolute inset-x-0 top-0 flex flex-col gap-2 p-3">
            <div className="pointer-events-auto flex gap-2 overflow-x-auto">
              {DUELS.map((d) => (
                <button
                  key={d.name}
                  type="button"
                  className="shrink-0 rounded-full border border-line bg-bg/80 px-3 py-1.5 text-xs text-muted backdrop-blur hover:border-brass hover:text-fg"
                  onClick={() => {
                    setVehicleId(d.vehicle);
                    setPlateId(d.plate);
                    setAmmoId(d.ammo);
                    setRangeM(d.range);
                    setMode("range");
                    setView("vehicle");
                    setUseOverride(false);
                    setResult(null);
                  }}
                >
                  {d.name}
                </button>
              ))}
            </div>
          </div>
          <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-2 p-3">
            <div className="rounded-md bg-bg/80 px-3 py-2 text-xs backdrop-blur">
              <div className="font-medium text-fg">{mode === "builder" ? draft.name : `${vehicle.name}`}</div>
              <div className="text-muted">
                {activePlate.name} · {activePlate.slopeDeg}° · {ammo.name}
              </div>
            </div>
            <div className="flex gap-1">
              {mode !== "builder" && (
                <button
                  type="button"
                  className="rounded-md border border-line bg-bg/80 px-3 py-2 text-xs backdrop-blur"
                  onClick={() => setView((v) => (v === "vehicle" ? "section" : "vehicle"))}
                >
                  {view === "vehicle" ? "Section" : "Vehicle"}
                </button>
              )}
              <button
                type="button"
                className="rounded-md border border-line bg-bg/80 px-3 py-2 text-xs backdrop-blur lg:hidden"
                onClick={() => setCatalogOpen(true)}
              >
                Catalog
              </button>
            </div>
          </div>
          {catalogOpen && (
            <button
              type="button"
              className="absolute inset-0 bg-bg/40 lg:hidden"
              aria-label="Close catalog"
              onClick={() => setCatalogOpen(false)}
            />
          )}
        </main>

        <aside className="scroll-thin min-h-0 overflow-y-auto border-t border-line bg-raised lg:border-t-0 lg:border-l">
          {mode === "builder" ? (
            <Builder
              draft={draft}
              setDraft={setDraft}
              schemes={schemes}
              onSave={() => {
                const id = draft.id.startsWith("user-") ? draft.id : `user-${Date.now()}`;
                const next = { ...draft, id };
                setDraft(next);
                setSchemes((list) => {
                  const i = list.findIndex((s) => s.id === id);
                  if (i >= 0) {
                    const copy = list.slice();
                    copy[i] = next;
                    return copy;
                  }
                  return [next, ...list];
                });
              }}
              onLoad={(s) => setDraft(s)}
              onDelete={(id) => setSchemes((list) => list.filter((s) => s.id !== id))}
              onAddAmmo={(a) => {
                setCustomAmmo((list) => [a, ...list]);
                setAmmoId(a.id);
              }}
            />
          ) : (
            <ShotPanel
              ammo={ammo}
              plate={activePlate}
              vehicleName={vehicle.name}
              rangeM={rangeM}
              setRangeM={setRangeM}
              yaw={yaw}
              setYaw={setYaw}
              useOverride={useOverride}
              setUseOverride={setUseOverride}
              override={override}
              setOverride={setOverride}
              gain={gain}
              setGain={setGain}
              impactV={impactV}
              onFire={fire}
              result={result}
              curve={curve}
            />
          )}
          {mode === "builder" && (
            <div className="border-t border-line p-4">
              <button
                type="button"
                onClick={fire}
                className="flex h-12 w-full items-center justify-center gap-2 rounded-md bg-brass font-semibold text-bg"
              >
                <Crosshair className="size-4" />
                Test this build
              </button>
              {result && <ResultBlock result={result} ammo={ammo} />}
            </div>
          )}
          <div className="border-t border-line p-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <div className="text-sm font-medium">Whole library</div>
                <div className="text-xs text-muted">
                  {library.length} rounds against this plate at {rangeM} m
                </div>
              </div>
              <button
                type="button"
                onClick={() => setBatch((b) => !b)}
                className="h-10 rounded-md border border-line px-3 text-sm hover:border-brass"
              >
                {batch ? "Hide" : "Run"}
              </button>
            </div>
            {batch && (
              <div className="mt-3">
                <div className="mb-2 font-mono text-xs text-muted">
                  {defeats} defeat the plate · {batchRows.length - defeats} do not
                </div>
                <ul className="max-h-80 space-y-1 overflow-auto">
                  {batchRows.map(({ ammo: a, shot }) => (
                    <li key={a.id}>
                      <button
                        type="button"
                        onClick={() => pickAmmo(a)}
                        className="flex w-full items-baseline justify-between gap-2 rounded px-1 py-1 text-left hover:bg-surface"
                      >
                        <span className="min-w-0 truncate text-sm">
                          <span className={cn("mr-2 font-mono text-[0.65rem]", verdictTone(shot.verdict))}>
                            {verdictShort(shot.verdict)}
                          </span>
                          {a.name}
                          <span className="text-faint"> · {a.gun}</span>
                        </span>
                        <span className="shrink-0 font-mono text-xs text-muted">{mm(shot.verticalPenMm)}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </aside>
      </div>

      {about && (
        <div className="fixed inset-0 z-20 grid place-items-center bg-bg/70 p-4" onClick={() => setAbout(false)}>
          <div
            className="scroll-thin max-h-[80vh] w-full max-w-lg overflow-y-auto rounded-lg border border-line bg-raised p-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3">
              <h2 className="text-lg font-semibold">What the numbers are</h2>
              <button type="button" onClick={() => setAbout(false)} aria-label="Close" className="text-muted">
                <X className="size-4" />
              </button>
            </div>
            <p className="mt-3 text-sm text-muted">
              The library is a curated proving ground — historical guns, naval shot, small arms, missiles — not every
              factory load ever made. That catalog does not exist in the open, and modern armor recipes are classified.
              Each round and each vehicle is tagged published, cited, estimate, or formula.
            </p>
            <ul className="mt-4 space-y-3 text-sm text-muted">
              {MODEL_NOTE.map((p) => (
                <li key={p}>{p}</li>
              ))}
            </ul>
            <p className="mt-4 text-xs text-faint">
              {VEHICLES.length} vehicles · {AMMUNITION.length} built-in rounds · angles are degrees from vertical.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

function Mark() {
  return (
    <svg width="28" height="28" viewBox="0 0 32 32" aria-hidden="true">
      <rect x="3" y="6" width="16" height="20" fill="#2c271f" stroke="#e2a857" strokeWidth="1.4" />
      <path d="M22 16h8M26 13l4 3-4 3" fill="none" stroke="#ff6a2a" strokeWidth="1.6" />
      <path d="M6 10h10M6 16h10M6 22h10" stroke="#8e959b" strokeWidth="1" />
    </svg>
  );
}

function Tab({
  on,
  onClick,
  icon,
  children,
}: {
  on: boolean;
  onClick: () => void;
  icon: ReactNode;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex h-10 items-center gap-1.5 rounded-md px-2.5 text-sm md:px-3",
        on ? "bg-surface text-fg" : "text-muted hover:text-fg",
      )}
    >
      {icon}
      <span className="hidden sm:inline">{children}</span>
    </button>
  );
}

function Catalog(props: {
  catalog: Catalog;
  setCatalog: (c: Catalog) => void;
  era: Era | "all";
  setEra: (e: Era | "all") => void;
  query: string;
  setQuery: (q: string) => void;
  vehicles: Vehicle[];
  rounds: Ammo[];
  vehicleId: string;
  ammoId: string;
  onVehicle: (v: Vehicle) => void;
  onAmmo: (a: Ammo) => void;
  countAmmo: number;
  countVehicles: number;
}) {
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex gap-1 border-b border-line p-2">
        <button
          type="button"
          className={cn("h-9 flex-1 rounded text-sm", props.catalog === "armor" ? "bg-surface text-fg" : "text-muted")}
          onClick={() => props.setCatalog("armor")}
        >
          Armor · {props.countVehicles}
        </button>
        <button
          type="button"
          className={cn("h-9 flex-1 rounded text-sm", props.catalog === "rounds" ? "bg-surface text-fg" : "text-muted")}
          onClick={() => props.setCatalog("rounds")}
        >
          Rounds · {props.countAmmo}
        </button>
      </div>
      <div className="border-b border-line p-2">
        <label className="flex h-10 items-center gap-2 rounded-md border border-line bg-bg px-2">
          <Search className="size-4 text-faint" />
          <input
            value={props.query}
            onChange={(e) => props.setQuery(e.target.value)}
            placeholder={props.catalog === "armor" ? "Vehicle, nation, year" : "Round, gun, caliber"}
            className="w-full bg-transparent text-sm outline-none placeholder:text-faint"
          />
        </label>
        <div className="mt-2 flex gap-1 overflow-x-auto">
          <Chip on={props.era === "all"} onClick={() => props.setEra("all")}>
            All
          </Chip>
          {ERAS.map((e) => (
            <Chip key={e} on={props.era === e} onClick={() => props.setEra(e)}>
              {ERA_LABEL[e]}
            </Chip>
          ))}
        </div>
      </div>
      <ul className="scroll-thin min-h-0 flex-1 overflow-y-auto">
        {props.catalog === "armor"
          ? props.vehicles.map((v) => (
              <li key={v.id}>
                <button
                  type="button"
                  onClick={() => props.onVehicle(v)}
                  className={cn(
                    "flex w-full flex-col items-start gap-0.5 border-b border-line px-3 py-2.5 text-left",
                    v.id === props.vehicleId ? "bg-surface" : "hover:bg-surface/60",
                  )}
                >
                  <span className="text-sm font-medium">{v.name}</span>
                  <span className="font-mono text-[0.65rem] text-faint">
                    {v.nation} · {v.year < 0 ? `${Math.abs(v.year)} BCE` : v.year} · {CONFIDENCE_LABEL[v.confidence]}
                  </span>
                </button>
              </li>
            ))
          : props.rounds.map((a) => (
              <li key={a.id}>
                <button
                  type="button"
                  onClick={() => props.onAmmo(a)}
                  className={cn(
                    "flex w-full flex-col items-start gap-0.5 border-b border-line px-3 py-2.5 text-left",
                    a.id === props.ammoId ? "bg-surface" : "hover:bg-surface/60",
                  )}
                >
                  <span className="text-sm font-medium">
                    {a.name}
                    <span className="ml-2 font-mono text-[0.65rem] text-faint">{TYPE_LABEL[a.type]}</span>
                  </span>
                  <span className="font-mono text-[0.65rem] text-faint">
                    {a.caliberMm} mm · {a.velocityMs} m/s · {a.gun}
                  </span>
                </button>
              </li>
            ))}
      </ul>
    </div>
  );
}

function Chip({ on, onClick, children }: { on: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-8 shrink-0 rounded-full border px-2.5 text-xs",
        on ? "border-brass bg-brass text-bg" : "border-line text-muted",
      )}
    >
      {children}
    </button>
  );
}

function ShotPanel(props: {
  ammo: Ammo;
  plate: Plate;
  vehicleName: string;
  rangeM: number;
  setRangeM: (n: number) => void;
  yaw: number;
  setYaw: (n: number) => void;
  useOverride: boolean;
  setUseOverride: (b: boolean) => void;
  override: number;
  setOverride: (n: number) => void;
  gain: number;
  setGain: (n: number) => void;
  impactV: number;
  onFire: () => void;
  result: ShotResult | null;
  curve: { r: number; pen: number; resist: number }[];
}) {
  const maxRange = props.ammo.caliberMm > 200 ? 20000 : 4000;
  const joules = energyJ(props.ammo.flightMassKg ?? props.ammo.massKg, props.impactV);
  return (
    <div className="p-4">
      <div className="text-[0.65rem] tracking-[0.14em] text-faint">ROUND</div>
      <h2 className="mt-1 text-lg font-semibold leading-tight">{props.ammo.name}</h2>
      <p className="text-sm text-muted">
        {props.ammo.gun} · {props.ammo.nation} · {props.ammo.year < 0 ? `${Math.abs(props.ammo.year)} BCE` : props.ammo.year}
      </p>
      <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-2 font-mono text-xs">
        <Stat k="Type" v={TYPE_LABEL[props.ammo.type]} />
        <Stat k="Caliber" v={`${props.ammo.caliberMm} mm`} />
        <Stat k="Mass" v={`${props.ammo.massKg} kg`} />
        <Stat k="Muzzle" v={ms(props.ammo.velocityMs)} />
        <Stat k="Impact" v={ms(props.impactV)} />
        <Stat k="Energy" v={joules > 1e6 ? `${(joules / 1e6).toFixed(2)} MJ` : `${Math.round(joules)} J`} />
        <Stat k="Plate" v={props.plate.name} />
        <Stat k="LOS" v={mm(plateLosMm(props.plate.layers, props.plate.slopeDeg))} />
      </dl>
      <p className="mt-2 text-[0.65rem] text-faint">{CONFIDENCE_LABEL[props.ammo.confidence]}</p>
      {props.ammo.note && <p className="mt-2 text-xs leading-relaxed text-muted">{props.ammo.note}</p>}

      <label className="mt-4 block text-xs text-muted">
        Range · {props.rangeM} m
        <input
          className="mt-2 w-full"
          type="range"
          min={0}
          max={maxRange}
          step={maxRange > 4000 ? 100 : 50}
          value={Math.min(props.rangeM, maxRange)}
          onChange={(e) => props.setRangeM(Number(e.target.value))}
        />
      </label>
      <label className="mt-3 block text-xs text-muted">
        Extra yaw · {props.yaw}°
        <input
          className="mt-2 w-full"
          type="range"
          min={0}
          max={60}
          value={props.yaw}
          onChange={(e) => props.setYaw(Number(e.target.value))}
        />
      </label>
      <label className="mt-3 flex items-center gap-2 text-xs text-muted">
        <input type="checkbox" checked={props.useOverride} onChange={(e) => props.setUseOverride(e.target.checked)} />
        Override impact speed
      </label>
      {props.useOverride && (
        <label className="mt-2 block text-xs text-muted">
          {props.override} m/s
          <input
            className="mt-2 w-full"
            type="range"
            min={50}
            max={2000}
            value={props.override}
            onChange={(e) => props.setOverride(Number(e.target.value))}
          />
        </label>
      )}
      <label className="mt-3 block text-xs text-muted">
        Plate thickness, visual · {props.gain}×
        <input
          className="mt-2 w-full"
          type="range"
          min={1}
          max={8}
          value={props.gain}
          onChange={(e) => props.setGain(Number(e.target.value))}
        />
      </label>

      <button
        type="button"
        onClick={props.onFire}
        className="mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-md bg-brass font-semibold text-bg"
      >
        <Crosshair className="size-4" />
        Fire
      </button>
      <p className="mt-2 text-center font-mono text-[0.65rem] text-faint">
        {props.vehicleName} · {props.plate.name}
      </p>

      <div className="mt-4 h-36">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={props.curve} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
            <CartesianGrid stroke="var(--color-line)" strokeDasharray="3 3" />
            <XAxis dataKey="r" tick={{ fill: "var(--color-faint)", fontSize: 10 }} stroke="var(--color-line)" />
            <YAxis tick={{ fill: "var(--color-faint)", fontSize: 10 }} stroke="var(--color-line)" width={36} />
            <Tooltip
              contentStyle={{ background: "#221e1a", border: "1px solid #3a332c", fontSize: 12 }}
              labelStyle={{ color: "#f3eadf" }}
            />
            <Line type="monotone" dataKey="pen" name="Vertical pen" stroke="var(--color-tracer)" dot={false} strokeWidth={2} />
            <Line type="monotone" dataKey="resist" name="Plate RHAe" stroke="var(--color-brass)" dot={false} strokeWidth={1.5} />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <p className="mt-1 text-[0.65rem] text-faint">
        Orange is vertical RHA perforation. Brass is this plate’s structural RHAe for this round — ERA and air are in the
        shot, not in that line.
      </p>
      {props.result && <ResultBlock result={props.result} ammo={props.ammo} />}
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <dt className="text-faint">{k}</dt>
      <dd className="text-fg">{v}</dd>
    </div>
  );
}

function verdictTone(v: ShotResult["verdict"]) {
  if (v === "perforation" || v === "spall") return "text-tracer";
  if (v === "partial" || v === "held") return "text-held";
  if (v === "ricochet") return "text-info";
  return "text-faint";
}
function verdictShort(v: ShotResult["verdict"]) {
  if (v === "perforation") return "THRU";
  if (v === "partial") return "STOP";
  if (v === "ricochet") return "RICO";
  if (v === "spall") return "SPALL";
  if (v === "dud") return "DUD";
  return "HELD";
}

function ResultBlock({ result, ammo }: { result: ShotResult; ammo: Ammo }) {
  return (
    <div className="mt-4 border-t border-line pt-4">
      <div className={cn("text-xl font-semibold tracking-tight", verdictTone(result.verdict))}>{result.headline}</div>
      <p className="mt-1 text-sm text-muted">{result.summary}</p>
      <dl className="mt-3 grid grid-cols-2 gap-2 font-mono text-xs">
        <Stat k="Obliquity" v={`${result.obliquityDeg.toFixed(0)}°`} />
        <Stat k="Vertical pen" v={ammo.type === "hesh" ? "—" : mm(result.verticalPenMm)} />
        <Stat k="Structural RHAe" v={mm(result.resistanceMm)} />
        <Stat k="Residual" v={result.residualV > 1 ? ms(result.residualV) : "—"} />
        <Stat k="Left in the round" v={result.residualPenMm > 1 ? mm(result.residualPenMm) : "—"} />
        <Stat k="Limit range" v={result.limitRangeM == null ? "beyond graph" : `${result.limitRangeM} m`} />
      </dl>
      <ol className="mt-3 space-y-2">
        {result.layers.map((layer) => (
          <li key={`${layer.index}-${layer.outcome}`} className="text-xs">
            <div className="flex justify-between gap-2 font-mono text-faint">
              <span>
                {String(layer.index + 1).padStart(2, "0")} {MATERIALS[layer.material].name} {Math.round(layer.thicknessMm)} mm
              </span>
              <span className={layer.outcome === "stopped" ? "text-held" : "text-muted"}>{layer.outcome}</span>
            </div>
            <p className="text-muted">{layer.note}</p>
          </li>
        ))}
      </ol>
      {result.caveats.length > 0 && (
        <ul className="mt-3 space-y-1 text-xs text-faint">
          {result.caveats.map((c) => (
            <li key={c}>{c}</li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Builder({
  draft,
  setDraft,
  schemes,
  onSave,
  onLoad,
  onDelete,
  onAddAmmo,
}: {
  draft: Scheme;
  setDraft: (s: Scheme) => void;
  schemes: Scheme[];
  onSave: () => void;
  onLoad: (s: Scheme) => void;
  onDelete: (id: string) => void;
  onAddAmmo: (a: Ammo) => void;
}) {
  function patch(partial: Partial<Scheme>) {
    setDraft({ ...draft, ...partial });
  }
  function setLayer(i: number, layer: Layer) {
    const layers = draft.layers.slice();
    layers[i] = layer;
    patch({ layers });
  }
  return (
    <div className="p-4">
      <div className="text-[0.65rem] tracking-[0.14em] text-faint">ARMOR BUILDER</div>
      <input
        value={draft.name}
        onChange={(e) => patch({ name: e.target.value })}
        className="mt-2 w-full border-b border-line bg-transparent text-lg font-semibold outline-none"
      />
      <label className="mt-3 block text-xs text-muted">
        Slope from vertical · {draft.slopeDeg}°
        <input
          className="mt-2 w-full"
          type="range"
          min={0}
          max={75}
          value={draft.slopeDeg}
          onChange={(e) => patch({ slopeDeg: Number(e.target.value) })}
        />
      </label>
      <div className="mt-3 flex flex-wrap gap-1">
        {TEACHING.map((t) => (
          <button
            key={t.scheme.id}
            type="button"
            className="h-8 rounded-full border border-line px-2.5 text-xs text-muted hover:border-brass"
            onClick={() => onLoad({ ...t.scheme, layers: t.scheme.layers.map((l) => ({ ...l })) })}
          >
            {t.name}
          </button>
        ))}
      </div>
      <ul className="mt-4 space-y-2">
        {draft.layers.map((layer, i) => (
          <li key={i} className="rounded-md border border-line bg-bg p-2">
            <div className="flex items-center gap-2">
              <span className="size-3 rounded-sm" style={{ background: MATERIALS[layer.material].color }} />
              <select
                value={layer.material}
                onChange={(e) => setLayer(i, { ...layer, material: e.target.value as MaterialId })}
                className="h-9 flex-1 rounded bg-surface px-2 text-sm outline-none"
              >
                {MATERIAL_ORDER.map((id) => (
                  <option key={id} value={id}>
                    {MATERIALS[id].name}
                  </option>
                ))}
              </select>
              <button
                type="button"
                aria-label="Remove layer"
                className="grid size-9 place-items-center text-muted hover:text-fg"
                onClick={() => patch({ layers: draft.layers.filter((_, j) => j !== i) })}
              >
                <Trash2 className="size-4" />
              </button>
            </div>
            <label className="mt-2 block font-mono text-xs text-muted">
              {Math.round(layer.thicknessMm)} mm
              <input
                className="mt-2 w-full"
                type="range"
                min={2}
                max={layer.material === "air" ? 800 : 500}
                value={layer.thicknessMm}
                onChange={(e) => setLayer(i, { ...layer, thicknessMm: Number(e.target.value) })}
              />
            </label>
            <p className="mt-1 text-[0.65rem] text-faint">{MATERIALS[layer.material].blurb}</p>
          </li>
        ))}
      </ul>
      <button
        type="button"
        className="mt-3 flex h-10 w-full items-center justify-center gap-2 rounded-md border border-line text-sm"
        onClick={() => patch({ layers: [...draft.layers, { material: "rha", thicknessMm: 40 }] })}
      >
        <Plus className="size-4" />
        Add layer
      </button>
      <div className="mt-3 flex gap-2">
        <button type="button" onClick={onSave} className="h-10 flex-1 rounded-md bg-surface text-sm">
          Save scheme
        </button>
      </div>
      {schemes.length > 0 && (
        <ul className="mt-3 space-y-1">
          {schemes.map((s) => (
            <li key={s.id} className="flex items-center gap-2 text-sm">
              <button type="button" className="flex-1 truncate text-left text-muted hover:text-fg" onClick={() => onLoad(s)}>
                {s.name}
              </button>
              <button type="button" aria-label="Delete scheme" className="text-faint hover:text-fg" onClick={() => onDelete(s.id)}>
                <Trash2 className="size-3.5" />
              </button>
            </li>
          ))}
        </ul>
      )}
      <CustomRound onAdd={onAddAmmo} />
    </div>
  );
}

function CustomRound({ onAdd }: { onAdd: (a: Ammo) => void }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("Custom round");
  const [type, setType] = useState<AmmoType>("apcbc");
  const [d, setD] = useState(75);
  const [m, setM] = useState(6.8);
  const [v, setV] = useState(750);
  const [pen, setPen] = useState(120);
  const [heat, setHeat] = useState(400);
  const [tandem, setTandem] = useState(false);
  const [rodL, setRodL] = useState(500);
  const [rodD, setRodD] = useState(24);
  const [saved, setSaved] = useState(false);

  if (!open) {
    return (
      <button type="button" className="mt-6 text-sm text-brass" onClick={() => setOpen(true)}>
        Add a round the library doesn’t have
      </button>
    );
  }
  return (
    <form
      className="mt-6 border-t border-line pt-4"
      onSubmit={(e) => {
        e.preventDefault();
        const ammo: Ammo = {
          id: `custom-${Date.now()}`,
          name,
          nation: "Custom",
          year: new Date().getFullYear(),
          era: "modern",
          gun: "Custom",
          type,
          caliberMm: d,
          massKg: m,
          velocityMs: v,
          confidence: "calculated",
          custom: true,
          note: "User-built round. Anchored to the penetration you typed, then scaled with velocity.",
          ...(type === "heat" || type === "hesh"
            ? { heatPenMm: heat, tandem, anchorPenMm: heat }
            : type === "apfsds"
              ? {
                  anchorPenMm: pen,
                  rodLengthMm: rodL,
                  rodDiameterMm: rodD,
                  core: "tungsten" as const,
                }
              : { anchorPenMm: pen }),
        };
        onAdd(ammo);
        setSaved(true);
      }}
    >
      <div className="text-sm font-medium">Custom round</div>
      <p className="mt-1 text-xs text-muted">
        Give it a vertical-RHA anchor. The curve around that anchor is the model’s, not a new proof trial.
      </p>
      <Field label="Name" value={name} onChange={setName} />
      <label className="mt-2 block text-xs text-muted">
        Type
        <select
          value={type}
          onChange={(e) => setType(e.target.value as AmmoType)}
          className="mt-1 h-10 w-full rounded bg-surface px-2 text-sm"
        >
          {(Object.keys(TYPE_LABEL) as AmmoType[]).map((t) => (
            <option key={t} value={t}>
              {TYPE_LABEL[t]}
            </option>
          ))}
        </select>
      </label>
      <div className="mt-2 grid grid-cols-3 gap-2">
        <Num label="mm" value={d} set={setD} />
        <Num label="kg" value={m} set={setM} />
        <Num label="m/s" value={v} set={setV} />
      </div>
      {type === "heat" || type === "hesh" ? (
        <div className="mt-2">
          <Num label="HEAT mm" value={heat} set={setHeat} />
          <label className="mt-2 flex items-center gap-2 text-xs text-muted">
            <input type="checkbox" checked={tandem} onChange={(e) => setTandem(e.target.checked)} />
            Tandem precursor
          </label>
        </div>
      ) : (
        <div className="mt-2 grid grid-cols-3 gap-2">
          <Num label="Pen mm" value={pen} set={setPen} />
          {type === "apfsds" && (
            <>
              <Num label="Rod L" value={rodL} set={setRodL} />
              <Num label="Rod D" value={rodD} set={setRodD} />
            </>
          )}
        </div>
      )}
      <button type="submit" className="mt-3 h-10 w-full rounded-md bg-surface text-sm">
        {saved ? "Saved" : "Save round"}
      </button>
    </form>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="mt-2 block text-xs text-muted">
      {label}
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 h-10 w-full rounded bg-surface px-2 text-sm text-fg outline-none"
      />
    </label>
  );
}

function Num({ label, value, set }: { label: string; value: number; set: (n: number) => void }) {
  return (
    <label className="block text-xs text-muted">
      {label}
      <input
        type="number"
        value={value}
        onChange={(e) => set(Number(e.target.value))}
        className="mt-1 h-10 w-full rounded bg-surface px-2 font-mono text-sm text-fg outline-none"
      />
    </label>
  );
}
