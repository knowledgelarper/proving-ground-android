import { OrbitControls } from "@react-three/drei";
import { Canvas, useFrame } from "@react-three/fiber";
import { useEffect, useMemo, useRef, type ReactNode } from "react";
import type { Group, Mesh } from "three";
import { MATERIALS } from "@/lib/ballistics/materials";
import type { Ammo, Layer, Place, Plate, ShotResult, Silhouette, Vehicle } from "@/lib/ballistics/types";

const DEG = Math.PI / 180;

function anchor(place: Place, silhouette: Silhouette): [number, number, number] {
  if (silhouette === "ship") {
    if (place === "roof") return [0, 1.55, 0.2];
    return [0, 0.95, 0.15];
  }
  if (silhouette === "turret") return [0, 1.15, 0];
  if (silhouette === "wagon") return place === "hull-side" ? [0.7, 0.7, 0] : [0, 0.85, 0.55];
  switch (place) {
    case "glacis":
      return [0, 0.95, 1.55];
    case "lfp":
      return [0, 0.42, 1.72];
    case "face":
      return [0, 0.9, 1.5];
    case "turret-front":
      return [0, 1.72, 0.42];
    case "mantlet":
      return [0, 1.62, 0.85];
    case "turret-side":
      return [0.78, 1.68, -0.05];
    case "turret-rear":
      return [0, 1.7, -0.85];
    case "hull-side":
      return [1.22, 0.62, 0.1];
    case "hull-rear":
      return [0, 0.7, -1.85];
    case "roof":
      return [0, 2.15, -0.1];
    case "belt":
      return [0, 0.9, 1.4];
    default:
      return [0, 1, 1.2];
  }
}

function visualThickness(layers: Layer[], gain: number): number {
  const mm = layers
    .filter((l) => !MATERIALS[l.material].air)
    .reduce((s, l) => s + Math.min(l.thicknessMm, MATERIALS[l.material].skinMm ?? l.thicknessMm), 0);
  return Math.min(0.62, Math.max(0.05, (mm * gain) / 1400));
}

function outerColor(layers: Layer[]): string {
  const hard = layers.find((l) => !MATERIALS[l.material].air);
  return hard ? MATERIALS[hard.material].color : "#8e959b";
}

function dims(place: Place, th: number, silhouette: Silhouette): [number, number, number] {
  if (silhouette === "ship") return [3.4, 1.5, th];
  if (silhouette === "wagon") return place === "hull-side" ? [th, 0.9, 1.6] : [1.5, 0.9, th];
  switch (place) {
    case "glacis":
    case "face":
      return [2.05, 1.05, th];
    case "lfp":
      return [2.05, 0.48, th];
    case "turret-front":
      return [1.35, 0.55, th];
    case "mantlet":
      return [0.7, 0.42, th];
    case "turret-side":
      return [th, 0.48, 1.15];
    case "turret-rear":
      return [1.2, 0.48, th];
    case "hull-side":
      return [th, 0.55, 2.6];
    case "hull-rear":
      return [2.0, 0.6, th];
    case "roof":
      return [1.3, th, 1.5];
    default:
      return [1.4, 0.8, th];
  }
}

function rotationFor(place: Place, slope: number): [number, number, number] {
  const pitch = -slope * DEG;
  if (place === "hull-side" || place === "turret-side") return [0, 0, 0];
  if (place === "hull-rear" || place === "turret-rear") return [pitch, Math.PI, 0];
  if (place === "roof") return [-Math.PI / 2, 0, 0];
  return [pitch, 0, 0];
}

function Body({ silhouette }: { silhouette: Silhouette }) {
  if (silhouette === "ship") {
    return (
      <group>
        <mesh position={[0, 0.7, -0.45]} castShadow receiveShadow>
          <boxGeometry args={[3.6, 1.7, 0.9]} />
          <meshStandardMaterial color="#3a3028" roughness={0.85} metalness={0.15} />
        </mesh>
        <mesh position={[0, 0.15, -0.2]}>
          <boxGeometry args={[4.2, 0.2, 1.6]} />
          <meshStandardMaterial color="#241c16" roughness={1} />
        </mesh>
      </group>
    );
  }
  if (silhouette === "turret") {
    return (
      <mesh position={[0, 1.05, 0]} castShadow>
        <cylinderGeometry args={[1.15, 1.15, 1.15, 20]} />
        <meshStandardMaterial color="#4a4038" metalness={0.45} roughness={0.55} />
      </mesh>
    );
  }
  if (silhouette === "wagon") {
    return (
      <group>
        <mesh position={[0, 0.55, 0]} castShadow>
          <boxGeometry args={[1.35, 0.7, 2.1]} />
          <meshStandardMaterial color="#5a3d28" roughness={0.9} />
        </mesh>
        <mesh position={[0.55, 0.28, 0.7]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.28, 0.28, 0.12, 12]} />
          <meshStandardMaterial color="#1c1916" />
        </mesh>
        <mesh position={[0.55, 0.28, -0.7]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.28, 0.28, 0.12, 12]} />
          <meshStandardMaterial color="#1c1916" />
        </mesh>
      </group>
    );
  }
  const light = silhouette === "light";
  const w = light ? 1.7 : 2.05;
  const len = silhouette === "casemate" ? 3.5 : light ? 3.3 : 4.1;
  return (
    <group>
      <mesh position={[0, 0.48, -0.05]} castShadow receiveShadow>
        <boxGeometry args={[w, 0.58, len]} />
        <meshStandardMaterial color="#2a261f" metalness={0.35} roughness={0.7} />
      </mesh>
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * (w / 2 + 0.16), 0.32, 0]} castShadow>
          <boxGeometry args={[0.28, 0.46, len + 0.35]} />
          <meshStandardMaterial color="#141311" roughness={0.95} metalness={0.2} />
        </mesh>
      ))}
      {silhouette !== "casemate" && (
        <mesh position={[0, 1.55, -0.15]} castShadow>
          <boxGeometry args={[light ? 1.05 : 1.45, 0.42, light ? 1.3 : 1.7]} />
          <meshStandardMaterial color="#322c26" metalness={0.4} roughness={0.6} />
        </mesh>
      )}
      <mesh position={[0, silhouette === "casemate" ? 1.15 : 1.62, 1.35]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[light ? 0.035 : 0.055, light ? 0.05 : 0.075, light ? 1.5 : 2.3, 10]} />
        <meshStandardMaterial color="#1e2226" metalness={0.7} roughness={0.35} />
      </mesh>
    </group>
  );
}

function Plates({
  vehicle,
  plateId,
  gain,
  onPick,
}: {
  vehicle: Vehicle;
  plateId: string;
  gain: number;
  onPick: (id: string) => void;
}) {
  return (
    <group>
      {vehicle.plates.map((plate) => {
        const pos = anchor(plate.place, vehicle.silhouette);
        const th = visualThickness(plate.layers, gain);
        const selected = plate.id === plateId;
        return (
          <mesh
            key={plate.id}
            position={pos}
            rotation={rotationFor(plate.place, plate.slopeDeg)}
            castShadow
            onClick={(e) => {
              e.stopPropagation();
              onPick(plate.id);
            }}
            onPointerOver={() => {
              document.body.style.cursor = "pointer";
            }}
            onPointerOut={() => {
              document.body.style.cursor = "";
            }}
          >
            <boxGeometry args={dims(plate.place, th, vehicle.silhouette)} />
            <meshStandardMaterial
              color={outerColor(plate.layers)}
              emissive={selected ? "#e2a857" : "#000000"}
              emissiveIntensity={selected ? 0.45 : 0}
              metalness={0.62}
              roughness={0.38}
            />
          </mesh>
        );
      })}
    </group>
  );
}

function Section({
  plate,
  gain,
  result,
}: {
  plate: Plate;
  gain: number;
  result: ShotResult | null;
}) {
  const layout = useMemo(() => {
    let z = 0;
    return plate.layers.map((layer) => {
      const mat = MATERIALS[layer.material];
      const depth = Math.max(mat.air ? 0.08 : 0.04, (layer.thicknessMm * gain) / 900);
      const item = { layer, z: z + depth / 2, depth, mat };
      z += depth + 0.045;
      return item;
    });
  }, [plate, gain]);

  const total = layout.length ? layout[layout.length - 1]!.z + layout[layout.length - 1]!.depth / 2 : 0;
  const channelDepth = result
    ? Math.min(
        total,
        layout.reduce((acc, item, i) => {
          const log = result.layers[i];
          if (!log) return acc;
          if (log.outcome === "stopped") return acc + item.depth * 0.65;
          return acc + item.depth + 0.045;
        }, 0),
      )
    : 0;

  return (
    <group position={[0, 1.05, 0]}>
      {layout.map((item) => (
        <mesh key={item.z} position={[0, 0, total / 2 - item.z]} castShadow>
          <boxGeometry args={[1.7, 1.15, item.depth]} />
          <meshStandardMaterial
            color={item.mat.color}
            metalness={item.mat.air ? 0 : 0.55}
            roughness={item.mat.air ? 1 : 0.4}
            transparent={Boolean(item.mat.air)}
            opacity={item.mat.air ? 0.25 : 1}
            wireframe={Boolean(item.mat.air)}
          />
        </mesh>
      ))}
      {result && channelDepth > 0.02 && (
        <mesh position={[0.15, 0, total / 2 - channelDepth / 2]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.035, 0.05, channelDepth, 10]} />
          <meshStandardMaterial
            color={result.verdict === "perforation" || result.verdict === "spall" ? "#ff6a2a" : "#e2a857"}
            emissive={result.verdict === "perforation" ? "#ff6a2a" : "#e2a857"}
            emissiveIntensity={0.8}
          />
        </mesh>
      )}
    </group>
  );
}

function RoundMesh({ type }: { type: Ammo["type"] }) {
  if (type === "shot") {
    return (
      <mesh>
        <sphereGeometry args={[0.09, 16, 12]} />
        <meshStandardMaterial color="#6a5648" metalness={0.4} roughness={0.45} />
      </mesh>
    );
  }
  if (type === "apfsds") {
    return (
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.012, 0.018, 0.62, 8]} />
        <meshStandardMaterial color="#d5dde3" metalness={0.85} roughness={0.2} />
      </mesh>
    );
  }
  if (type === "heat" || type === "hesh" || type === "he") {
    return (
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.045, 0.07, 0.32, 10]} />
        <meshStandardMaterial color="#8a5a32" metalness={0.5} roughness={0.4} />
      </mesh>
    );
  }
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]}>
      <cylinderGeometry args={[0.045, 0.07, 0.38, 12]} />
      <meshStandardMaterial color="#c2b59a" metalness={0.7} roughness={0.3} />
    </mesh>
  );
}

function Flyer({
  token,
  ammo,
  target,
  reduced,
}: {
  token: number;
  ammo: Ammo;
  target: [number, number, number];
  reduced: boolean;
}) {
  const ref = useRef<Group>(null);
  const start = useRef<number | null>(null);
  const tx = target[0];
  const ty = target[1];
  const tz = target[2];
  const fromX = tx;
  const fromY = ty + 0.15;
  const fromZ = tz + 3.4;

  useEffect(() => {
    start.current = null;
    const g = ref.current;
    if (!g) return;
    g.position.set(fromX, fromY, fromZ);
    g.lookAt(tx, ty, tz);
  }, [token, fromX, fromY, fromZ, tx, ty, tz]);

  useFrame((state) => {
    const g = ref.current;
    if (!g) return;
    if (token === 0) {
      g.visible = false;
      return;
    }
    if (start.current == null) start.current = state.clock.elapsedTime;
    const dur = reduced ? 0.05 : 0.38;
    const t = Math.min(1, (state.clock.elapsedTime - start.current) / dur);
    const e = t * t * (3 - 2 * t);
    g.visible = t < 1;
    g.position.set(fromX + (tx - fromX) * e, fromY + (ty - fromY) * e, fromZ + (tz - fromZ) * e);
  });

  return (
    <group ref={ref} visible={false}>
      <RoundMesh type={ammo.type} />
    </group>
  );
}

function ShakeGroup({ shake, children }: { shake: number; children: ReactNode }) {
  const ref = useRef<Group>(null);
  const amp = useRef(0);
  useEffect(() => {
    amp.current = Math.max(amp.current, shake);
  }, [shake]);
  useFrame((state, delta) => {
    const d = Math.min(delta, 0.1);
    amp.current *= Math.exp(-d * 6);
    const g = ref.current;
    if (!g) return;
    const t = state.clock.elapsedTime;
    g.position.x = Math.sin(t * 54) * amp.current * 0.05;
    g.position.y = Math.cos(t * 47) * amp.current * 0.03;
  });
  return <group ref={ref}>{children}</group>;
}

export type SceneProps = {
  vehicle: Vehicle | null;
  plate: Plate;
  ammo: Ammo;
  gain: number;
  view: "vehicle" | "section";
  shotToken: number;
  result: ShotResult | null;
  onPick: (id: string) => void;
};

export function Scene({
  vehicle,
  plate,
  ammo,
  gain,
  view,
  shotToken,
  result,
  onPick,
}: SceneProps) {
  const reduced = useMemo(
    () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    [],
  );
  const target: [number, number, number] =
    view === "section" || !vehicle ? [0, 1.05, 0.4] : anchor(plate.place, vehicle.silhouette);
  const shake = shotToken > 0 && result ? (result.verdict === "perforation" ? 1 : 0.45) : 0;

  return (
    <Canvas
      camera={{ position: [3.1, 1.7, 4.4], fov: 38, near: 0.1, far: 40 }}
      dpr={[1, 1.6]}
      shadows
      gl={{ antialias: true, powerPreference: "high-performance" }}
    >
      <color attach="background" args={["#100e0c"]} />
      <fog attach="fog" args={["#100e0c", 9, 22]} />
      <hemisphereLight args={["#f4e6d4", "#2a2118", 0.7]} />
      <directionalLight
        position={[5, 8, 4]}
        intensity={2.4}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
      />
      <directionalLight position={[-4, 3, -2]} intensity={0.45} color="#9ec0d4" />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <circleGeometry args={[8, 48]} />
        <meshStandardMaterial color="#171410" roughness={1} metalness={0} />
      </mesh>
      <gridHelper args={[12, 12, "#3a332c", "#241f1a"]} position={[0, 0.01, 0]} />
      <ShakeGroup shake={shake}>
        {view === "vehicle" && vehicle ? (
          <group>
            <Body silhouette={vehicle.silhouette} />
            <Plates vehicle={vehicle} plateId={plate.id} gain={gain} onPick={onPick} />
          </group>
        ) : (
          <Section plate={plate} gain={gain} result={result} />
        )}
        <Flyer token={shotToken} ammo={ammo} target={target} reduced={reduced} />
        <Spark token={shotToken} target={target} verdict={result?.verdict} />
      </ShakeGroup>
      <OrbitControls
        makeDefault
        enablePan={false}
        minDistance={2.2}
        maxDistance={11}
        maxPolarAngle={Math.PI / 2.05}
        target={[0, 0.9, 0.2]}
      />
    </Canvas>
  );
}

function Spark({
  token,
  target,
  verdict,
}: {
  token: number;
  target: [number, number, number];
  verdict?: ShotResult["verdict"];
}) {
  const ref = useRef<Mesh>(null);
  const start = useRef<number | null>(null);
  useEffect(() => {
    start.current = null;
  }, [token]);
  useFrame((state) => {
    const m = ref.current;
    if (!m) return;
    if (!token || !verdict) {
      m.visible = false;
      return;
    }
    if (start.current == null) start.current = state.clock.elapsedTime;
    const t = state.clock.elapsedTime - start.current;
    m.visible = t > 0.36 && t < 1.3;
    const k = Math.max(0, 1 - (t - 0.36) / 0.9);
    m.scale.setScalar(0.15 + (1 - k) * 0.8);
    const mat = m.material;
    if (!Array.isArray(mat) && "opacity" in mat) mat.opacity = k;
  });
  const color = verdict === "perforation" || verdict === "spall" ? "#ff6a2a" : "#e2a857";
  return (
    <mesh ref={ref} position={target} visible={false}>
      <sphereGeometry args={[0.18, 12, 10]} />
      <meshBasicMaterial color={color} transparent opacity={0.9} />
    </mesh>
  );
}
