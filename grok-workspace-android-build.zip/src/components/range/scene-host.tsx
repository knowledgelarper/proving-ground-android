import { useEffect, useState, type ComponentType } from "react";
import type { SceneProps } from "./scene";

export function SceneHost(props: SceneProps) {
  const [Comp, setComp] = useState<ComponentType<SceneProps> | null>(null);
  useEffect(() => {
    let live = true;
    void import("./scene").then((mod) => {
      if (live) setComp(() => mod.Scene);
    });
    return () => {
      live = false;
    };
  }, []);
  if (!Comp) {
    return (
      <div className="absolute inset-0 grid place-items-center bg-bg text-sm text-muted">
        Setting the range
      </div>
    );
  }
  return <Comp {...props} />;
}
