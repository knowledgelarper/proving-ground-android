import { cp, mkdir, readdir, rm } from "node:fs/promises";
import { existsSync } from "node:fs";
import { join, resolve } from "node:path";

const candidates = [".output/public", ".vercel/output/static", "dist/client", "dist", "build"];
let source = null;
for (const candidate of candidates) {
  if (!existsSync(candidate)) continue;
  const hasShell = existsSync(join(candidate, "_shell.html"));
  const hasIndex = existsSync(join(candidate, "index.html"));
  if (hasIndex || hasShell) {
    source = candidate;
    if (hasIndex) break;
  }
}
if (!source) {
  throw new Error(
    `Could not find the built web assets. Checked: ${candidates.join(", ")}. ` +
    "Review the previous Vite build output before packaging Android.",
  );
}

const target = "mobile-www";
await rm(target, { recursive: true, force: true });
await mkdir(target, { recursive: true });
await cp(source, target, { recursive: true });

const targetIndex = join(target, "index.html");
if (!existsSync(targetIndex) && existsSync(join(target, "_shell.html"))) {
  await cp(join(target, "_shell.html"), targetIndex);
}
if (!existsSync(targetIndex)) {
  throw new Error(`Build assets copied from ${source}, but no index.html was found.`);
}

const entries = await readdir(target, { withFileTypes: true });
console.log(`Prepared Capacitor web assets from ${resolve(source)} to ${resolve(target)}.`);
console.log(`Top-level entries: ${entries.map((e) => e.name).join(", ")}`);
